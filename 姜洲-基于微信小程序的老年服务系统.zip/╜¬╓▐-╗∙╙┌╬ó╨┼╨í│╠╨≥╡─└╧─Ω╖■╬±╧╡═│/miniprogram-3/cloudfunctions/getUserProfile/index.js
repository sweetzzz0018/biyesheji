const cloud = require('wx-server-sdk')
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  
  try {
    // 获取用户信息
    const userInfo = await cloud.getUserInfo({
      openId: wxContext.OPENID,
      appId: wxContext.APPID,
      unionId: wxContext.UNIONID,
    })
    
    return {
      userInfo: userInfo.userInfo
    }
  } catch (err) {
    console.error('获取用户信息失败:', err)
    return {
      errCode: 1,
      errMsg: '获取用户信息失败'
    }
  }
}
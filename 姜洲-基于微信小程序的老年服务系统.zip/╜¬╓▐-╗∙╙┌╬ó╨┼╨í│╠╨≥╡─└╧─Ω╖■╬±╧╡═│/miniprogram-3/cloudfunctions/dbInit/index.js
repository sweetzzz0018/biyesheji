const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

exports.main = async (event, context) => {
  if (event.action === 'setPermission') {
    // 设置moments集合权限
    await cloud.database().collection('moments').where({}).update({
      data: {
        _permission: {
          read: "auth != null",
          write: "auth != null"
        }
      }
    })
    
    return { success: true }
  }
  
  return { error: '未知操作' }
}
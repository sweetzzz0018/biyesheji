// 云函数入口文件
const cloud = require('wx-server-sdk');
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV // 自动使用当前云环境
})

// 云函数入口函数
exports.main = async (event, context) => {
  const { code, userInfo } = event;
  const wxContext = cloud.getWXContext();
  const openid = wxContext.OPENID;

  // 将用户信息存入数据库，使用标准格式
  const db = cloud.database();
  const _ = db.command;

  // 标准化用户信息
  const standardUserInfo = {
    nickName: userInfo?.nickName || '微信用户',
    avatarUrl: userInfo?.avatarUrl || 'https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0K1...',
    gender: userInfo?.gender || 0,
    country: userInfo?.country || '',
    province: userInfo?.province || '',
    city: userInfo?.city || '',
    language: userInfo?.language || ''
  };

  try {
    // 先检查用户是否存在
    const userRecord = await db.collection('users').where({ openid }).get();

    if (userRecord.data.length > 0) {
      // 用户已存在，更新信息
      await db.collection('users').where({ openid }).update({
        data: {
          ...standardUserInfo,
          lastLogin: db.serverDate(),
          loginCount: _.inc(1)
        }
      });
    } else {
      // 用户不存在，创建新用户
      await db.collection('users').add({
        data: {
          openid,
          ...standardUserInfo,
          createTime: db.serverDate()
        }
      });
    }
  } catch (err) {
    console.error('用户数据操作失败:', err);
  }

  return {
    openid,
    userInfo: standardUserInfo
  };
};
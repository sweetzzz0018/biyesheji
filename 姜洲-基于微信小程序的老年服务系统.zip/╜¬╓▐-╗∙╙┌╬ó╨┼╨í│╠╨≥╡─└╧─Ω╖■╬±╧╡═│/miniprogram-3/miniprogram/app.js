App({
  onLaunch() {
    // 初始化云开发（自动管理登录态）
    wx.cloud.init({
      env: 'cloud1-0gdsjui311f1ca70',
      traceUser: true // 关键配置！自动缓存登录凭证
    });

    // 尝试恢复登录状态
    this.restoreLoginState();
  },

  globalData: {
    userInfo: null,
    openid: null,
    isLogin: false
  },

  async restoreLoginState() {
    try {
      const { code } = await wx.login();
      const res = await wx.cloud.callFunction({
        name: 'login', // 确保这个基础云函数存在
        data: { code }
      });
      this.globalData.openid = res.result.openid;
    } catch (err) {
      console.error('获取openid失败:', err);
    }
  },

  // 统一登录方法 - 只获取openid，不获取用户信息
  async userLogin() {
    try {
      // 1. 获取code（兼容异常场景）
      const { code } = await wx.login().catch(() => {
        throw new Error('获取登录凭证失败');
      });

      // 2. 获取openid
      const { result } = await wx.cloud.callFunction({
        name: 'getOpenId',
        data: { code }
      });

      // 3. 存储基础信息
      this.globalData.openid = result.openid;
      this.globalData.isLogin = true;

      // 4. 尝试从数据库获取用户信息
      try {
        const db = wx.cloud.database();
        const userRes = await db.collection('users').where({
          openid: result.openid
        }).get();

        if (userRes.data.length > 0) {
          // 如果数据库中有用户信息，则使用数据库中的信息
          this.globalData.userInfo = userRes.data[0];

          // 5. 持久化到本地
          wx.setStorageSync('userCache', {
            openid: result.openid,
            isLogin: true,
            userInfo: this.globalData.userInfo
          });

          return;
        }
      } catch (dbErr) {
        console.error('从数据库获取用户信息失败:', dbErr);
      }

      // 如果没有获取到用户信息，只存储openid
      wx.setStorageSync('userCache', {
        openid: result.openid,
        isLogin: true
      });

    } catch (err) {
      console.error('登录流程异常:', err);
      wx.showToast({ title: '登录失败，请重试', icon: 'none' });
      throw err; // 抛出异常供调用方处理
    }
  },

  // 获取用户信息（优化版）
  async getUserInfo() {
    try {
      const { userInfo } = await wx.getUserProfile({
        desc: '用于完善会员资料'
      });

      // 更新全局数据
      this.globalData.userInfo = userInfo;

      // 同步到云数据库
      await this.syncToCloudDatabase(userInfo);

    } catch (err) {
      if (err.errMsg.includes('auth deny')) {
        console.log('用户拒绝授权');
      } else {
        console.error('获取用户信息失败:', err);
      }
      throw err;
    }
  },

  // 同步到云数据库（新增）
  async syncToCloudDatabase(userInfo) {
    const db = wx.cloud.database();
    const _ = db.command;

    // 确保用户信息格式统一
    const standardUserInfo = {
      nickName: userInfo.nickName || '微信用户',
      avatarUrl: userInfo.avatarUrl || 'https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0K1...', // 默认头像
      gender: userInfo.gender || 0,
      country: userInfo.country || '',
      province: userInfo.province || '',
      city: userInfo.city || '',
      language: userInfo.language || ''
    };

    try {
      // 先尝试更新
      const updateResult = await db.collection('users').where({
        openid: this.globalData.openid
      }).update({
        data: {
          ...standardUserInfo,
          lastLogin: _.set(new Date()),
          loginCount: _.inc(1)
        }
      });

      // 如果没有更新任何记录，则创建新记录
      if (updateResult.stats.updated === 0) {
        await db.collection('users').add({
          data: {
            ...standardUserInfo,
            openid: this.globalData.openid,
            createTime: new Date()
          }
        });
      }

      // 更新全局用户信息，确保包含openid
      this.globalData.userInfo = {
        ...standardUserInfo,
        openid: this.globalData.openid
      };

    } catch (err) {
      console.error('同步用户数据失败:', err);
      // 如果更新失败，尝试创建新记录
      await db.collection('users').add({
        data: {
          ...standardUserInfo,
          openid: this.globalData.openid,
          createTime: new Date()
        }
      });
    }
  },

  // 退出登录
  logout() {
    // 清空全局状态
    this.globalData = {
      userInfo: null,
      openid: null,
      isLogin: false
    };

    // 清除本地缓存
    wx.removeStorageSync('userCache');

    // 跳转到登录页（可选）
    wx.reLaunch({ url: '/pages/login/login' });
  }
});
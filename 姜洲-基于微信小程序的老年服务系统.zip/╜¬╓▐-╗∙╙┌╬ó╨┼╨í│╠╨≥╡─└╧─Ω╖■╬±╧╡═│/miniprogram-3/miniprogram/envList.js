const envList = [{"envId":"cloud1-0gdsjui311f1ca70","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}
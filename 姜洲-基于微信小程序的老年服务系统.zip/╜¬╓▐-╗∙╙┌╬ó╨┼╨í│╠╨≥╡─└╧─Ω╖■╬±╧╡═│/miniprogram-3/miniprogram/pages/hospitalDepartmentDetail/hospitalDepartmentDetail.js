// pages/hospitalDepartmentDetail/hospitalDepartmentDetail.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    department: null,
    doctors: [],
    selectedDoctor: null,
    features: [
      '专业医师团队',
      '先进医疗设备',
      '舒适就医环境',
      '一站式医疗服务'
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    if (options.departmentInfo) {
      try {
        const department = JSON.parse(decodeURIComponent(options.departmentInfo));
        this.setData({ department });
        this.loadDoctors(department.name);
      } catch (error) {
        console.error('解析科室信息失败:', error);
        wx.showToast({
          title: '加载科室信息失败',
          icon: 'none'
        });
      }
    } else {
      wx.showToast({
        title: '科室信息不存在',
        icon: 'none'
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },

  /**
   * 加载科室医生
   */
  loadDoctors(departmentName) {
    // 模拟从数据库加载医生数据
    // 实际应用中，应该从云数据库获取
    const doctorsData = {
      '内科': [
        { id: 101, name: '张医生', title: '主任医师', specialty: '心血管疾病' },
        { id: 102, name: '李医生', title: '副主任医师', specialty: '消化系统疾病' },
        { id: 103, name: '王医生', title: '主治医师', specialty: '呼吸系统疾病' }
      ],
      '外科': [
        { id: 201, name: '刘医生', title: '主任医师', specialty: '普通外科' },
        { id: 202, name: '陈医生', title: '副主任医师', specialty: '骨科' },
        { id: 203, name: '杨医生', title: '主治医师', specialty: '神经外科' }
      ],
      '妇产科': [
        { id: 301, name: '赵医生', title: '主任医师', specialty: '妇科肿瘤' },
        { id: 302, name: '钱医生', title: '副主任医师', specialty: '产科' },
        { id: 303, name: '孙医生', title: '主治医师', specialty: '妇科内分泌' }
      ],
      '儿科': [
        { id: 401, name: '周医生', title: '主任医师', specialty: '小儿内科' },
        { id: 402, name: '吴医生', title: '副主任医师', specialty: '新生儿科' },
        { id: 403, name: '郑医生', title: '主治医师', specialty: '小儿外科' }
      ],
      '眼科': [
        { id: 501, name: '冯医生', title: '主任医师', specialty: '白内障' },
        { id: 502, name: '陆医生', title: '副主任医师', specialty: '青光眼' },
        { id: 503, name: '卢医生', title: '主治医师', specialty: '视网膜疾病' }
      ],
      '耳鼻喉科': [
        { id: 601, name: '蒋医生', title: '主任医师', specialty: '鼻科疾病' },
        { id: 602, name: '沈医生', title: '副主任医师', specialty: '耳科疾病' },
        { id: 603, name: '韩医生', title: '主治医师', specialty: '咽喉科疾病' }
      ],
      '呼吸科': [
        { id: 701, name: '朱医生', title: '主任医师', specialty: '肺结核' },
        { id: 702, name: '秦医生', title: '副主任医师', specialty: '肺炎' },
        { id: 703, name: '尤医生', title: '主治医师', specialty: '哮喘' }
      ],
      '皮肤科': [
        { id: 801, name: '许医生', title: '主任医师', specialty: '皮肤病理' },
        { id: 802, name: '何医生', title: '副主任医师', specialty: '皮肤过敏' },
        { id: 803, name: '吕医生', title: '主治医师', specialty: '皮肤美容' }
      ],
      '神经科': [
        { id: 901, name: '施医生', title: '主任医师', specialty: '脑血管疾病' },
        { id: 902, name: '张医生', title: '副主任医师', specialty: '癫痫' },
        { id: 903, name: '孔医生', title: '主治医师', specialty: '头痛' }
      ],
      '精神科': [
        { id: 1001, name: '曹医生', title: '主任医师', specialty: '抑郁症' },
        { id: 1002, name: '谢医生', title: '副主任医师', specialty: '焦虑症' },
        { id: 1003, name: '邹医生', title: '主治医师', specialty: '精神分裂症' }
      ],
      '中医科': [
        { id: 1101, name: '姚医生', title: '主任医师', specialty: '中医内科' },
        { id: 1102, name: '崔医生', title: '副主任医师', specialty: '针灸推拿' },
        { id: 1103, name: '钟医生', title: '主治医师', specialty: '中医妇科' }
      ],
      '肿瘤科': [
        { id: 1201, name: '谭医生', title: '主任医师', specialty: '肺癌' },
        { id: 1202, name: '毛医生', title: '副主任医师', specialty: '胃癌' },
        { id: 1203, name: '廖医生', title: '主治医师', specialty: '血液肿瘤' }
      ]
    };

    // 获取对应科室的医生
    const doctors = doctorsData[departmentName] || [];
    this.setData({ doctors });
  },

  /**
   * 选择医生
   */
  selectDoctor(e) {
    const doctorId = e.currentTarget.dataset.id;
    const doctor = this.data.doctors.find(item => item.id === doctorId);
    this.setData({ selectedDoctor: doctor });
  },

  /**
   * 跳转到预约页面
   */
  goToBooking() {
    if (!this.data.department) return;

    // 获取科室索引
    const departmentIndex = this.getDepartmentIndex(this.data.department.name);
    
    // 构建URL参数
    let url = `/pages/addAppointment/addAppointment?departmentIndex=${departmentIndex}`;
    
    // 如果选择了医生，添加医生信息
    if (this.data.selectedDoctor) {
      url += `&doctorName=${this.data.selectedDoctor.name}`;
    }
    
    wx.navigateTo({ url });
  },

  /**
   * 获取科室在预约页面中的索引
   */
  getDepartmentIndex(departmentName) {
    const departments = [
      '内科', '外科', '妇产科', '儿科', '眼科', 
      '耳鼻喉科', '口腔科', '皮肤科', '神经科', 
      '精神科', '中医科', '肿瘤科', '其他'
    ];
    
    return departments.findIndex(dept => dept === departmentName);
  }
})

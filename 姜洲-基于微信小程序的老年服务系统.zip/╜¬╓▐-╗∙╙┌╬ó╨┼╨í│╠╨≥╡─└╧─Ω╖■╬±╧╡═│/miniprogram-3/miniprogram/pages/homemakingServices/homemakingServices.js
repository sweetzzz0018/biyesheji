// pages/homemakingServices/homemakingServices.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    serviceTypes: [
      {
        id: 1,
        name: '日常保洁',
        icon: '/imgs/homemaking/daily_cleaning.png',
        description: '提供家居日常清洁服务，包括打扫卫生、除尘、拖地等基础保洁工作。',
      },
      {
        id: 2,
        name: '深度保洁',
        icon: '/imgs/homemaking/deep_cleaning.png',
        description: '提供全面彻底的清洁服务，包括死角清洁、顽固污渍处理等深度保洁工作。',
      },
      {
        id: 3,
        name: '家电清洗',
        icon: '/imgs/homemaking/appliance_cleaning.png',
        description: '专业清洗各类家用电器，包括空调、冰箱、洗衣机等家电设备。',
      },
      {
        id: 4,
        name: '厨房保洁',
        icon: '/imgs/homemaking/kitchen_cleaning.png',
        description: '专注厨房区域的深度清洁，包括油烟机、灶台、橱柜等厨房设备的清洁。',
      },
      {
        id: 5,
        name: '卫生间保洁',
        icon: '/imgs/homemaking/bathroom_cleaning.png',
        description: '专业清洁卫生间区域，包括马桶、浴缸、洗手台等卫浴设备的消毒清洁。',
      },
      {
        id: 6,
        name: '新房保洁',
        icon: '/imgs/homemaking/initial_cleaning.png',
        description: '针对新房装修后或长期未使用的房屋提供的全面清洁服务。',
      },
      {
        id: 9,
        name: '老人陪护',
        icon: '/imgs/homemaking/elderly_care.png',
        description: '为老年人提供生活照料、陪伴聊天、户外活动等服务。',
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 页面加载时可以执行的逻辑
  },

  /**
   * 点击服务卡片，跳转到服务详情页
   */
  goToServiceDetail(e) {
    const serviceId = e.currentTarget.dataset.id;
    const service = this.data.serviceTypes.find(item => item.id === serviceId);
    
    // 将服务信息转为JSON字符串，通过URL参数传递
    const serviceInfo = encodeURIComponent(JSON.stringify(service));
    
    wx.navigateTo({
      url: `/pages/homemakingServiceDetail/homemakingServiceDetail?serviceInfo=${serviceInfo}`
    });
  }
})

Page({
  data: {
    appointments: [],
    userId: '',
    isLoading: false
  },

  onLoad() {
    const app = getApp();

    // 检查用户信息是否存在
    if (app.globalData.userInfo) {
      const openid = app.globalData.userInfo.openid;
      // 通过 openid 查询 userId
      this.loadUserId(openid);
    } else if (app.globalData.openid) {
      // 如果userInfo不存在但openid存在，直接使用openid
      this.loadUserId(app.globalData.openid);
    } else {
      // 如果都不存在，提示用户登录
      wx.showToast({
        title: '请先登录',
        icon: 'none',
        duration: 2000
      });

      // 跳转到登录页面
      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/login/login'
        });
      }, 2000);
    }
  },

  onShow() {
    if (this.data.userId) {
      this.loadAppointments();
    }

    // 检查是否需要刷新
    const needRefresh = wx.getStorageSync('hospital_need_refresh');
    if (needRefresh) {
      // 清除标记
      wx.removeStorageSync('hospital_need_refresh');
      // 刷新数据
      this.loadAppointments();
    }
  },

  // 通过 openid 查询 userId
  async loadUserId(openid) {
    const db = wx.cloud.database();
    try {
      const res = await db.collection('users').where({ openid }).get();

      if (res.data.length > 0) {
        const userId = res.data[0]._id; // 获取 userId
        this.setData({ userId });

        // 加载预约列表
        this.loadAppointments();
      } else {
        console.error('未找到用户');
        wx.showToast({
          title: '未找到用户',
          icon: 'none',
        });
      }
    } catch (err) {
      console.error('加载用户信息失败:', err);
      wx.showToast({
        title: '加载用户信息失败',
        icon: 'none',
      });
    }
  },

  // 加载预约列表
  async loadAppointments() {
    if (this.data.isLoading) return;
    this.setData({ isLoading: true });

    wx.showLoading({ title: '加载中...' });

    try {
      const db = wx.cloud.database();
      const _ = db.command;

      // 查询当前用户的所有预约
      const res = await db.collection('medical')
        .where({
          userId: this.data.userId
        })
        .orderBy('createTime', 'desc')
        .get();

      // 格式化时间
      const appointments = res.data.map(item => ({
        ...item,
        formattedCreateTime: this.formatDate(item.createTime)
      }));

      this.setData({ appointments });
    } catch (err) {
      console.error('加载预约失败:', err);
      wx.showToast({
        title: '加载预约失败',
        icon: 'none'
      });
    } finally {
      this.setData({ isLoading: false });
      wx.hideLoading();
    }
  },

  // 格式化日期
  formatDate(timestamp) {
    if (!timestamp) return '';

    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');

    return `${year}-${month}-${day} ${hours}:${minutes}`;
  },

  // 查看预约详情
  viewAppointmentDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/appointmentDetail/appointmentDetail?id=${id}`
    });
  },

  // 取消预约
  cancelAppointment(e) {
    const id = e.currentTarget.dataset.id;

    wx.showModal({
      title: '确认取消',
      content: '确定要取消这个预约吗？',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '取消中...' });

          try {
            const db = wx.cloud.database();
            await db.collection('medical').doc(id).update({
              data: {
                status: '已取消',
                updateTime: db.serverDate()
              }
            });

            wx.showToast({
              title: '取消成功',
              icon: 'success'
            });

            // 重新加载预约列表
            this.loadAppointments();
          } catch (err) {
            console.error('取消预约失败:', err);
            wx.showToast({
              title: '取消失败',
              icon: 'none'
            });
          } finally {
            wx.hideLoading();
          }
        }
      }
    });
  },

  // 前往科室选择页面
  goToAddAppointment() {
    wx.navigateTo({
      url: '/pages/hospitalDepartments/hospitalDepartments'
    });
  }
});

const db = wx.cloud.database()

Page({
  data: {
    id: '',
    announcement: {
      content: '',
      images: [],
      createTime: null,
      views: 0
    }
  },

  onLoad(options) {
    if (!options.id) {
      wx.showToast({ title: '参数错误', icon: 'none' })
      return wx.navigateBack()
    }

    this.setData({ id: options.id })
    this.loadAnnouncement()
  },

  // 加载公告详情
  loadAnnouncement() {
    wx.showLoading({ title: '加载中...' })

    db.collection('announcements').doc(this.data.id).get()
      .then(res => {
        if (!res.data) throw new Error('公告不存在')
        this.setData({ announcement: res.data })
        this.updateViews()
      })
      .catch(err => {
        console.error('加载失败:', err)
        wx.showToast({ 
          title: err.errCode === -502005 ? '数据库未初始化' : '加载失败',
          icon: 'none' 
        })
        setTimeout(() => wx.navigateBack(), 1500)
      })
      .finally(() => wx.hideLoading())
  },

  // 更新浏览量
  updateViews() {
    db.collection('announcements').doc(this.data.id).update({
      data: { views: db.command.inc(1) }
    }).catch(console.error)
  },

  // 内容变更
  onContentChange(e) {
    this.setData({
      'announcement.content': e.detail.value
    })
  },

  // 添加图片
  addImage() {
    const remain = 9 - this.data.announcement.images.length
    wx.chooseImage({
      count: remain,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showLoading({ title: '上传中...', mask: true })
        
        const uploadTasks = res.tempFilePaths.map((path, index) => {
          return wx.cloud.uploadFile({
            cloudPath: `announcements/${Date.now()}-${index}.jpg`,
            filePath: path
          })
        })

        Promise.all(uploadTasks)
          .then(res => {
            const newImages = res.map(item => item.fileID)
            this.setData({
              'announcement.images': [...this.data.announcement.images, ...newImages]
            })
          })
          .catch(err => {
            console.error('上传失败:', err)
            wx.showToast({ title: '上传失败', icon: 'none' })
          })
          .finally(() => wx.hideLoading())
      }
    })
  },

  // 删除图片
  removeImage(e) {
    const index = e.currentTarget.dataset.index
    const images = [...this.data.announcement.images]
    images.splice(index, 1)
    this.setData({ 'announcement.images': images })
  },

  // 图片预览
  previewImage(e) {
    wx.previewImage({
      current: e.currentTarget.dataset.url,
      urls: e.currentTarget.dataset.urls
    })
  },

  // 保存修改
  saveChanges() {
    if (!this.data.announcement.content.trim()) {
      return wx.showToast({ title: '请输入公告内容', icon: 'none' })
    }

    wx.showLoading({ title: '保存中...', mask: true })

    const updateData = {
      content: this.data.announcement.content,
      images: this.data.announcement.images,
      updateTime: db.serverDate()
    }

    db.collection('announcements').doc(this.data.id).update({
      data: updateData
    })
    .then(() => {
      wx.showToast({ title: '保存成功', icon: 'success' })
      setTimeout(() => wx.navigateBack(), 1500)
    })
    .catch(err => {
      console.error('保存失败:', err)
      wx.showToast({ title: '保存失败', icon: 'none' })
    })
    .finally(() => wx.hideLoading())
  },

  // 格式化时间
  formatTime(timestamp) {
    if (!timestamp) return '未知时间'
    const date = new Date(timestamp)
    const year = date.getFullYear()
    const month = (date.getMonth() + 1).toString().padStart(2, '0')
    const day = date.getDate().toString().padStart(2, '0')
    const hours = date.getHours().toString().padStart(2, '0')
    const minutes = date.getMinutes().toString().padStart(2, '0')
    return `${year}-${month}-${day} ${hours}:${minutes}`
  },

  // 返回
  navigateBack() {
    wx.navigateBack()
  }
})
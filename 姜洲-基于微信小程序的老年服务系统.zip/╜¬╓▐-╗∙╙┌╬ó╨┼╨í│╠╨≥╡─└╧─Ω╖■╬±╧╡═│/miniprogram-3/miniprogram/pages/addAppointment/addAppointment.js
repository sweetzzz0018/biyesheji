Page({
  data: {
    userId: '',
    hospitalName: '',
    departmentIndex: -1,
    departments: ['内科', '外科', '妇产科', '儿科', '眼科', '耳鼻喉科', '口腔科', '皮肤科', '神经科', '精神科', '中医科', '肿瘤科', '其他'],
    doctorName: '',
    appointmentDate: '',
    timeSlotIndex: -1,
    timeSlots: ['上午 8:00-10:00', '上午 10:00-12:00', '下午 14:00-16:00', '下午 16:00-18:00'],
    patientName: '',
    genderIndex: -1,
    genders: ['男', '女'],
    patientAge: '',
    patientPhone: '',
    patientIdCard: '',
    symptoms: '',
    minDate: '',
    maxDate: ''
  },

  onLoad(options) {
    // 设置日期范围（今天到30天后）
    const today = new Date();
    const minDate = this.formatDate(today);

    const maxDate = new Date();
    maxDate.setDate(today.getDate() + 30);

    // 初始化数据
    let initialData = {
      minDate,
      maxDate: this.formatDate(maxDate),
      appointmentDate: minDate
    };

    // 如果有传入科室索引，则设置
    if (options && options.departmentIndex) {
      initialData.departmentIndex = parseInt(options.departmentIndex);
    }

    // 如果有传入医生名称，则设置
    if (options && options.doctorName) {
      initialData.doctorName = options.doctorName;
    }

    this.setData(initialData);

    // 获取用户ID
    const app = getApp();
    if (app.globalData.userInfo) {
      this.loadUserId(app.globalData.userInfo.openid);
    } else if (app.globalData.openid) {
      this.loadUserId(app.globalData.openid);
    } else {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },

  // 通过 openid 查询 userId
  async loadUserId(openid) {
    const db = wx.cloud.database();
    try {
      const res = await db.collection('users').where({ openid }).get();
      if (res.data.length > 0) {
        this.setData({
          userId: res.data[0]._id,
          patientName: res.data[0].nickName || ''
        });
      } else {
        wx.showToast({ title: '未找到用户', icon: 'none' });
      }
    } catch (err) {
      console.error('加载用户信息失败:', err);
      wx.showToast({ title: '加载用户信息失败', icon: 'none' });
    }
  },

  // 格式化日期为 YYYY-MM-DD
  formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  },

  // 通用输入处理
  onInputChange(e) {
    const { field } = e.currentTarget.dataset;
    this.setData({ [field]: e.detail.value });
  },

  // 科室选择
  onDepartmentChange(e) {
    this.setData({ departmentIndex: parseInt(e.detail.value) });
  },

  // 日期选择
  onDateChange(e) {
    this.setData({ appointmentDate: e.detail.value });
  },

  // 时间段选择
  onTimeChange(e) {
    this.setData({ timeSlotIndex: parseInt(e.detail.value) });
  },

  // 性别选择
  onGenderChange(e) {
    this.setData({ genderIndex: parseInt(e.detail.value) });
  },

  // 提交预约
  async submitAppointment() {
    // 表单验证
    const {
      userId,
      hospitalName,
      departmentIndex,
      departments,
      appointmentDate,
      timeSlotIndex,
      timeSlots,
      patientName,
      genderIndex,
      genders,
      patientAge,
      patientPhone
    } = this.data;

    if (!userId) {
      wx.showToast({ title: '用户未登录', icon: 'none' });
      return;
    }

    if (!hospitalName) {
      wx.showToast({ title: '请输入医院名称', icon: 'none' });
      return;
    }

    if (departmentIndex < 0) {
      wx.showToast({ title: '请选择科室', icon: 'none' });
      return;
    }

    if (!appointmentDate) {
      wx.showToast({ title: '请选择预约日期', icon: 'none' });
      return;
    }

    if (timeSlotIndex < 0) {
      wx.showToast({ title: '请选择预约时间段', icon: 'none' });
      return;
    }

    if (!patientName) {
      wx.showToast({ title: '请输入患者姓名', icon: 'none' });
      return;
    }

    if (genderIndex < 0) {
      wx.showToast({ title: '请选择患者性别', icon: 'none' });
      return;
    }

    if (!patientAge) {
      wx.showToast({ title: '请输入患者年龄', icon: 'none' });
      return;
    }

    if (!patientPhone) {
      wx.showToast({ title: '请输入联系电话', icon: 'none' });
      return;
    }

    // 手机号格式验证
    if (!/^1\d{10}$/.test(patientPhone)) {
      wx.showToast({ title: '手机号格式不正确', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '提交中...' });

    try {
      const db = wx.cloud.database();

      // 生成预约号
      const appointmentNumber = this.generateAppointmentNumber();

      // 保存预约信息
      await db.collection('medical').add({
        data: {
          userId,
          hospitalName,
          department: departments[departmentIndex],
          doctorName: this.data.doctorName,
          appointmentDate,
          appointmentTime: timeSlots[timeSlotIndex],
          patientName,
          gender: genders[genderIndex],
          patientAge,
          patientPhone,
          patientIdCard: this.data.patientIdCard,
          symptoms: this.data.symptoms,
          status: '待确认',
          appointmentNumber,
          createTime: db.serverDate(),
          updateTime: db.serverDate()
        }
      });

      wx.hideLoading();

      // 设置刷新标记
      wx.setStorageSync('hospital_need_refresh', true);

      wx.showToast({
        title: '预约成功',
        icon: 'success'
      });

      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    } catch (err) {
      wx.hideLoading();
      console.error('预约失败:', err);
      wx.showToast({
        title: '预约失败',
        icon: 'none'
      });
    }
  },

  // 生成预约号
  generateAppointmentNumber() {
    const date = new Date();
    const year = date.getFullYear().toString().slice(2);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');

    return `A${year}${month}${day}${random}`;
  },


});

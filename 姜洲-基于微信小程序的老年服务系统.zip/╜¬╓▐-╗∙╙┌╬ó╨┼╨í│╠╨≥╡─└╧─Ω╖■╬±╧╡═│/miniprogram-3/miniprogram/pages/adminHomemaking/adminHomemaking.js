// pages/adminHomemaking/adminHomemaking.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    appointments: [],
    isLoading: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    this.loadAppointments();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    this.loadAppointments();
  },

  // 加载所有预约
  async loadAppointments() {
    if (this.data.isLoading) return;
    this.setData({ isLoading: true });

    wx.showLoading({ title: '加载中...' });

    try {
      const db = wx.cloud.database();
      
      // 查询所有家政服务预约，按创建时间倒序排列
      const res = await db.collection('homemaking')
        .orderBy('createTime', 'desc')
        .get();

      // 格式化时间
      const appointments = res.data.map(item => ({
        ...item,
        formattedCreateTime: this.formatDate(item.createTime)
      }));

      this.setData({ appointments });
    } catch (err) {
      console.error('加载预约失败:', err);
      wx.showToast({
        title: '加载预约失败',
        icon: 'none'
      });
    } finally {
      this.setData({ isLoading: false });
      wx.hideLoading();
    }
  },

  // 格式化日期
  formatDate(timestamp) {
    if (!timestamp) return '';
    
    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hour = date.getHours().toString().padStart(2, '0');
    const minute = date.getMinutes().toString().padStart(2, '0');
    
    return `${year}-${month}-${day} ${hour}:${minute}`;
  },

  // 更新预约状态
  async updateStatus(e) {
    const { id, status } = e.currentTarget.dataset;
    
    wx.showModal({
      title: '确认修改',
      content: `确定要将此预约状态修改为"${status}"吗？`,
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '更新中...' });
          
          try {
            const db = wx.cloud.database();
            await db.collection('homemaking').doc(id).update({
              data: {
                status: status,
                updateTime: db.serverDate()
              }
            });
            
            wx.showToast({
              title: '更新成功',
              icon: 'success'
            });
            
            // 重新加载预约列表
            this.loadAppointments();
          } catch (err) {
            console.error('更新预约状态失败:', err);
            wx.showToast({
              title: '更新失败',
              icon: 'none'
            });
          } finally {
            wx.hideLoading();
          }
        }
      }
    });
  }
});

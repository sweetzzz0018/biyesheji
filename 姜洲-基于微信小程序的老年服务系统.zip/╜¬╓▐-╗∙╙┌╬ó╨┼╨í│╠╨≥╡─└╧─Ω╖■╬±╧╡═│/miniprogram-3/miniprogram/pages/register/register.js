Page({
  data: {
    username: '', // 用户名
    password: '', // 密码
  },

  // 输入用户名
  onInputUsername(e) {
    this.setData({ username: e.detail.value });
  },

  // 输入密码
  onInputPassword(e) {
    this.setData({ password: e.detail.value });
  },

  // 跳转到登录页面
  goToLogin() {
    wx.navigateTo({
      url: '/pages/login/login',
    });
  },

  // 注册
  async onRegister() {
    const { username, password } = this.data;

    if (!username || !password) {
      wx.showToast({
        title: '请输入用户名和密码',
        icon: 'none',
      });
      return;
    }

    wx.showLoading({
      title: '注册中...',
    });

    try {
      const db = wx.cloud.database();
      const res = await db.collection('users').where({
        username,
      }).get();

      if (res.data.length > 0) {
        // 用户名已存在
        wx.hideLoading();
        wx.showToast({
          title: '用户名已存在',
          icon: 'none',
        });
      } else {
        // 插入新用户
        await db.collection('users').add({
          data: {
            username,
            password,
            createdAt: new Date(),
          },
        });

        wx.hideLoading();
        wx.showToast({
          title: '注册成功',
          icon: 'success',
        });

        // 跳转到登录页面
        wx.navigateTo({
          url: '/pages/login/login',
        });
      }
    } catch (err) {
      wx.hideLoading();
      wx.showToast({
        title: '注册失败',
        icon: 'none',
      });
      console.error('注册失败:', err);
    }
  },
});
// pages/serviceCards/serviceCards.js
Page({
  data: {
    cards: [
      {
        id: 1,
        title: '医疗服务卡',
        icon: '/imgs/index/Medical.png',
        balance: '¥200',
        expireDate: '2024-12-31',
        status: '有效'
      },
      {
        id: 2,
        title: '家政服务卡',
        icon: '/imgs/index/homemaking.png',
        balance: '¥150',
        expireDate: '2024-10-15',
        status: '有效'
      },
      {
        id: 3,
        title: '健康体检卡',
        icon: '/imgs/index/healthtwo.png',
        balance: '3次',
        expireDate: '2024-09-30',
        status: '有效'
      }
    ]
  },

  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '服务卡包'
    });
  },

  viewCardDetail: function(e) {
    const cardId = e.currentTarget.dataset.id;
    wx.showToast({
      title: '查看卡详情功能开发中',
      icon: 'none'
    });
  },

  rechargeCard: function(e) {
    const cardId = e.currentTarget.dataset.id;
    wx.showToast({
      title: '充值功能开发中',
      icon: 'none'
    });
  },

  goBack: function() {
    wx.navigateBack();
  }
})

// pages/post/post.js
const db = wx.cloud.database()
const _ = db.command

Page({
  data: {
    content: '',
    images: [],
    isSubmitting: false,
    error: null,
    hasUnsavedChanges: false // 新增状态标记
  },

  onLoad() {
    // 初始化时检查数据库
    this.checkDatabase()
  },

  // 1. 返回按钮事件处理
  goBack() {
    if (this.data.hasUnsavedChanges) {
      wx.showModal({
        title: '提示',
        content: '您有未保存的内容，确定要返回吗？',
        success: (res) => {
          if (res.confirm) {
            wx.navigateBack()
          }
        }
      })
    } else {
      wx.navigateBack()
    }
  },

  // 2. 数据库存在性检查
  async checkDatabase() {
    try {
      await db.collection('moments').count()
    } catch (err) {
      if (err.errCode === 'DATABASE_COLLECTION_NOT_EXIST') {
        await this.initDatabase()
      }
    }
  },

  // 3. 自动初始化数据库
  async initDatabase() {
    wx.showLoading({ title: '初始化数据库...' })
    try {
      await db.createCollection('moments')
      console.log('moments集合创建成功')

      await wx.cloud.callFunction({
        name: 'dbInit',
        data: { action: 'setPermission' }
      })
    } catch (err) {
      console.error('初始化失败:', err)
      this.setData({ error: '数据库初始化失败，请稍后重试' })
    } finally {
      wx.hideLoading()
    }
  },

  // 4. 发布动态（带重试机制）
  async submitPost() {
    if (!this.data.content.trim()) {
      wx.showToast({ title: '请填写内容', icon: 'none' })
      return
    }
    if (this.data.isSubmitting) return

    this.setData({
      isSubmitting: true,
      error: null
    })

    try {
      await this.trySubmit(2)
      this.setData({ hasUnsavedChanges: false }) // 发布成功后重置状态
    } catch (err) {
      this.handleSubmitError(err)
    } finally {
      this.setData({ isSubmitting: false })
    }
  },

  // 5. 带重试的提交逻辑
  async trySubmit(retryCount) {
    try {
      const imageUrls = await this.uploadImages()
      await this.saveToDatabase(imageUrls)

      // 设置刷新标记，通知社区页面需要刷新
      wx.setStorageSync('moments_need_refresh', true)

      wx.showToast({ title: '发布成功' })
      setTimeout(() => {
        wx.navigateBack()
      }, 1500)
    } catch (err) {
      if (err.errCode === 'DATABASE_COLLECTION_NOT_EXIST' && retryCount > 0) {
        console.log(`正在重试，剩余次数: ${retryCount}`)
        await this.initDatabase()
        return this.trySubmit(retryCount - 1)
      }
      throw err
    }
  },

  // 6. 图片上传
  async uploadImages() {
    if (this.data.images.length === 0) return []

    const uploadTasks = this.data.images.map((img, index) =>
      wx.cloud.uploadFile({
        cloudPath: `moments/${Date.now()}-${index}.jpg`,
        filePath: img
      })
    )

    const uploadRes = await Promise.all(uploadTasks)
    return uploadRes.map(item => item.fileID)
  },

  // 7. 数据库保存
  async saveToDatabase(imageUrls) {
    const app = getApp();
    const userInfo = app.globalData.userInfo;
    const openid = app.globalData.openid;

    // 默认用户信息
    let userData = {
      avatarUrl: '/imgs/default-avatar.png',
      nickName: '微信用户',
      openid: openid || ''
    };

    let userId = null;

    try {
      if (!openid) {
        throw new Error('用户未登录');
      }

      // 1. 先从users集合获取userId
      const userRes = await db.collection('users').where({ openid }).get();

      if (userRes.data.length > 0) {
        userId = userRes.data[0]._id;

        // 2. 使用userId从userdata集合获取详细信息
        try {
          const userdataRes = await db.collection('userdata').where({ userId }).get();

          if (userdataRes.data.length > 0) {
            // 如果在userdata中找到了用户信息，使用其中的昵称和头像
            userData = {
              nickName: userdataRes.data[0].nickName || '微信用户',
              avatarUrl: userdataRes.data[0].avatarUrl || '/imgs/default-avatar.png',
              openid
            };
            console.log('从userdata获取到用户信息:', userData.nickName);
          } else {
            // 如果在userdata中找不到，使用users集合中的信息
            userData = {
              nickName: userRes.data[0].nickName || '微信用户',
              avatarUrl: userRes.data[0].avatarUrl || '/imgs/default-avatar.png',
              openid
            };
          }
        } catch (userdataErr) {
          console.error('从userdata获取用户信息失败:', userdataErr);
          // 使用users集合中的信息作为备选
          userData = {
            nickName: userRes.data[0].nickName || '微信用户',
            avatarUrl: userRes.data[0].avatarUrl || '/imgs/default-avatar.png',
            openid
          };
        }
      } else {
        // 如果在users集合中找不到，尝试直接从userdata集合通过openid查询
        try {
          const directUserdataRes = await db.collection('userdata').where({ openid }).get();
          if (directUserdataRes.data.length > 0) {
            userData = {
              nickName: directUserdataRes.data[0].nickName || '微信用户',
              avatarUrl: directUserdataRes.data[0].avatarUrl || '/imgs/default-avatar.png',
              openid
            };
            console.log('通过openid从userdata获取到用户信息:', userData.nickName);
          }
        } catch (directErr) {
          console.error('通过openid从userdata获取用户信息失败:', directErr);
        }
      }
    } catch (err) {
      console.error('获取用户信息失败:', err);
    }

    await db.collection('moments').add({
      data: {
        content: this.data.content,
        images: imageUrls,
        userId: userId, // 保存用户ID，可能为null
        user: userData,
        likes: [],
        comments: [],
        createTime: db.serverDate()
      }
    });
  },

  // 8. 错误处理
  handleSubmitError(err) {
    console.error('发布失败:', err)

    let errorMsg = '发布失败'

    if (err) {
      if (err.errCode === 'DATABASE_COLLECTION_NOT_EXIST') {
        errorMsg = '数据库未准备好，请退出重试'
      } else if (err.errMsg && err.errMsg.includes && err.errMsg.includes('cloudPath')) {
        errorMsg = '图片上传失败'
      } else if (err.message) {
        // 如果是标准Error对象
        errorMsg = err.message
      }
    }

    this.setData({ error: errorMsg })
    wx.showToast({
      title: errorMsg,
      icon: 'none'
    })
  },

  // 9. 选择图片
  chooseImage() {
    wx.chooseImage({
      count: 9 - this.data.images.length,
      success: res => {
        this.setData({
          images: [...this.data.images, ...res.tempFilePaths],
          hasUnsavedChanges: true // 标记有未保存更改
        })
      }
    })
  },

  // 10. 删除图片
  removeImage(e) {
    const index = e.currentTarget.dataset.index
    const newImages = [...this.data.images]
    newImages.splice(index, 1)
    this.setData({
      images: newImages,
      hasUnsavedChanges: newImages.length > 0 || this.data.content.trim() !== ''
    })
  },

  // 11. 内容变化监听
  onContentChange(e) {
    this.setData({
      content: e.detail.value,
      hasUnsavedChanges: e.detail.value.trim() !== '' || this.data.images.length > 0
    })
  },

  // 12. 页面卸载时处理（可选）
  onUnload() {
    // 可以在这里保存草稿到缓存
    if (this.data.hasUnsavedChanges) {
      wx.setStorageSync('draft_post', {
        content: this.data.content,
        images: this.data.images
      })
    }
  },

  // 13. 页面加载时恢复草稿（可选）
  onLoad() {
    this.checkDatabase()

    // 恢复草稿
    const draft = wx.getStorageSync('draft_post')
    if (draft) {
      this.setData({
        content: draft.content,
        images: draft.images,
        hasUnsavedChanges: true
      })
      wx.showModal({
        title: '提示',
        content: '检测到有未发布的草稿，是否继续编辑？',
        success: (res) => {
          if (!res.confirm) {
            wx.removeStorageSync('draft_post')
            this.setData({
              content: '',
              images: [],
              hasUnsavedChanges: false
            })
          }
        }
      })
    }
  }
})
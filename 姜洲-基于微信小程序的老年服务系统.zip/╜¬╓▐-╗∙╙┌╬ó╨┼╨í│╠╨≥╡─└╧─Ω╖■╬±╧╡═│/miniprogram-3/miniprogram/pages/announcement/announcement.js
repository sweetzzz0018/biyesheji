const db = wx.cloud.database()
const _ = db.command

Page({
  data: {
    announcements: []
  },

  onLoad() {
    this.loadAnnouncements()
  },

  onShow() {
    this.loadAnnouncements()
  },

  loadAnnouncements() {
    wx.showLoading({ title: '加载中...' })
    
    db.collection('announcements')
      .orderBy('createTime', 'desc')
      .get()
      .then(res => {
        this.setData({ announcements: res.data })
        // 更新浏览量
        res.data.forEach(item => {
          db.collection('announcements').doc(item._id).update({
            data: { views: _.inc(1) }
          })
        })
      })
      .catch(err => {
        console.error('加载失败:', err)
        wx.showToast({ title: '加载失败', icon: 'none' })
      })
      .finally(() => wx.hideLoading())
  },

  formatTime(timestamp) {
    const date = new Date(timestamp)
    return `${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()} ${date.getHours()}:${date.getMinutes()}`
  },

  // 查看公告详情
  viewAnnouncement(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: `/pages/announcementDetail/announcementDetail?id=${id}`
    })
  },

  // 跳转到编辑页面（修改后）
  goToEdit() {
    wx.navigateTo({
      url: '/pages/announcementPublish/announcementPublish'
    })
  },

  // 返回上一页
  navigateBack() {
    wx.navigateBack()
  }
})
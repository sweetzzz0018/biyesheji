Page({
  data: {
    userId: '',
    recordId: '', // 编辑时使用
    date: '',
    hospital: '',
    bloodPressure: '',
    bloodSugar: '', // 新增血糖字段
    heartRate: '',
    height: '',
    weight: '',
    bmi: '',
    bmiEvaluation: '',
    notes: '',
    images: [],
    urineOptions: ['阴性', '+-', '+', '++', '+++'],
    
    // 血常规
    bloodTest: {
      wbc: '',     // 白细胞
      rbc: '',     // 红细胞
      hgb: '',     // 血红蛋白
      plt: '',     // 血小板
    },
    
    // 尿常规
    urineTest: {
      protein: '',
      proteinIndex: -1,
      glucose: '',
      glucoseIndex: -1,
      blood: '',
      bloodIndex: -1
    },
    
    // 肝功能
    liverFunction: {
      alt: '',      // 谷丙转氨酶
      ast: '',      // 谷草转氨酶
      tbil: ''     // 总胆红素
    },
    
    // 肾功能
    kidneyFunction: {
      crea: '',     // 肌酐
      bun: '',      // 尿素氮
      ua: ''       // 尿酸
    }
  },

  onLoad(options) {
    const openid = getApp().globalData.userInfo.openid;
    this.loadUserId(openid);
    this.setData({ 
      date: this.getCurrentDateTime(),
      recordId: options.id || '' // 如果有ID则是编辑模式
    });

    if (options.id) {
      this.loadRecordData(options.id);
    }
  },

  // 加载用户ID
  async loadUserId(openid) {
    const db = wx.cloud.database();
    try {
      const res = await db.collection('users').where({ openid }).get();
      if (res.data.length > 0) {
        this.setData({ userId: res.data[0]._id });
      } else {
        wx.showToast({ title: '未找到用户', icon: 'none' });
      }
    } catch (err) {
      wx.showToast({ title: '用户信息加载失败', icon: 'none' });
      console.error('用户加载失败:', err);
    }
  },

  // 加载已有记录数据
  async loadRecordData(recordId) {
    wx.showLoading({ title: '加载中...' });
    try {
      const db = wx.cloud.database();
      const res = await db.collection('medicalRecords').doc(recordId).get();

      if (res.data) {
        const data = res.data;
        // 处理尿常规的索引值
        const urineOptions = this.data.urineOptions;
        const urineTest = data.urineTest || {};
        
        this.setData({
          hospital: data.hospital || '',
          date: data.date || this.getCurrentDateTime(),
          bloodPressure: data.bloodPressure || '',
          bloodSugar: data.bloodSugar || '', // 新增血糖字段
          heartRate: data.heartRate || '',
          height: data.height || '',
          weight: data.weight || '',
          bmi: data.bmi || '',
          bmiEvaluation: data.bmi ? this.getBMIEvaluation(data.bmi) : '',
          notes: data.notes || '',
          images: data.images || [],
          bloodTest: data.bloodTest || {
            wbc: '', rbc: '', hgb: '', plt: ''
          },
          urineTest: {
            protein: urineTest.protein || '',
            proteinIndex: urineOptions.indexOf(urineTest.protein || ''),
            glucose: urineTest.glucose || '',
            glucoseIndex: urineOptions.indexOf(urineTest.glucose || ''),
            blood: urineTest.blood || '',
            bloodIndex: urineOptions.indexOf(urineTest.blood || '')
          },
          liverFunction: data.liverFunction || {
            alt: '', ast: '', tbil: ''
          },
          kidneyFunction: data.kidneyFunction || {
            crea: '', bun: '', ua: ''
          }
        });
      }
    } catch (err) {
      wx.showToast({ title: '加载失败', icon: 'none' });
      console.error('加载记录失败:', err);
    } finally {
      wx.hideLoading();
    }
  },

  // 获取当前日期时间
  getCurrentDateTime() {
    const date = new Date();
    return date.toISOString().slice(0, 19).replace('T', ' ');
  },

  // 通用输入处理
  onInputChange(e) {
    const { field } = e.currentTarget.dataset;
    this.setData({ [field]: e.detail.value });
  },

  // 身高体重变化处理
  onBodyDataChange(e) {
    const { field } = e.currentTarget.dataset;
    this.setData({ 
      [field]: e.detail.value 
    }, () => {
      this.calculateBMI();
    });
  },

  calculateBMI() {
    const { height, weight } = this.data;
    if (height && weight) {
      const heightInMeter = parseFloat(height) / 100;
      const bmiValue = (parseFloat(weight) / (heightInMeter * heightInMeter)).toFixed(1);
      this.setData({ 
        bmi: bmiValue,
        bmiEvaluation: this.getBMIEvaluation(bmiValue)
      });
    } else {
      this.setData({ 
        bmi: '',
        bmiEvaluation: ''
      });
    }
  },

  getBMIEvaluation(bmi) {
    bmi = parseFloat(bmi);
    if (isNaN(bmi)) return '';
    if (bmi < 18.5) return "偏瘦";
    if (bmi < 24) return "正常";
    if (bmi < 28) return "超重";
    return "肥胖";
  },

  // 血常规输入处理
  onBloodTestChange(e) {
    const { field } = e.currentTarget.dataset;
    this.setData({
      [`bloodTest.${field}`]: e.detail.value
    });
  },

  // 尿常规选择处理
  onUrineTestChange(e) {
    const { field } = e.currentTarget.dataset;
    const value = e.detail.value;
    const urineOptions = this.data.urineOptions;
    
    this.setData({
      [`urineTest.${field}`]: urineOptions[value],
      [`urineTest.${field}Index`]: value
    });
  },

  // 肝功能输入处理
  onLiverFunctionChange(e) {
    const { field } = e.currentTarget.dataset;
    this.setData({
      [`liverFunction.${field}`]: e.detail.value
    });
  },

  // 肾功能输入处理
  onKidneyFunctionChange(e) {
    const { field } = e.currentTarget.dataset;
    this.setData({
      [`kidneyFunction.${field}`]: e.detail.value
    });
  },

  // 上传图片
  async uploadImage() {
    if (this.data.images.length >= 3) {
      wx.showToast({ title: '最多上传3张图片', icon: 'none' });
      return;
    }

    try {
      const res = await wx.chooseImage({
        count: 3 - this.data.images.length,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera']
      });

      wx.showLoading({ title: '上传中...' });

      const uploadTasks = res.tempFilePaths.map(file => {
        const fileName = `medical-imgs/${Date.now()}-${Math.floor(Math.random() * 1000)}.jpg`;
        return wx.cloud.uploadFile({ 
          cloudPath: fileName, 
          filePath: file 
        });
      });

      const results = await Promise.all(uploadTasks);
      const newImages = results.map(item => item.fileID);

      this.setData({ 
        images: [...this.data.images, ...newImages] 
      });
    } catch (err) {
      wx.showToast({ title: '上传失败', icon: 'none' });
      console.error('图片上传失败:', err);
    } finally {
      wx.hideLoading();
    }
  },

  // 预览图片
  previewImage(e) {
    wx.previewImage({
      current: e.currentTarget.dataset.url,
      urls: this.data.images
    });
  },

  // 删除图片
  removeImage(e) {
    const { index } = e.currentTarget.dataset;
    const images = [...this.data.images];
    images.splice(index, 1);
    this.setData({ images });
  },

  // 保存数据
  async saveData() {
    const { 
      userId, 
      recordId,
      date, 
      hospital,
      bloodPressure,
      bloodSugar, // 新增血糖字段
      heartRate,
      height,
      weight,
      bmi,
      notes,
      images,
      bloodTest,
      urineTest,
      liverFunction,
      kidneyFunction
    } = this.data;

    if (!userId) {
      wx.showToast({ title: '用户未登录', icon: 'none' });
      return;
    }

    if (!hospital) {
      wx.showToast({ title: '请填写检查医院', icon: 'none' });
      return;
    }

    wx.showLoading({ title: '保存中...' });

    try {
      const db = wx.cloud.database();
      // 整理尿常规数据，去除索引字段
      const { proteinIndex, glucoseIndex, bloodIndex, ...cleanUrineTest } = urineTest;
      
      const data = { 
        userId, 
        date, 
        hospital, 
        bloodPressure,
        bloodSugar, // 新增血糖字段
        heartRate,
        height,
        weight,
        bmi,
        notes, 
        images,
        bloodTest,
        urineTest: cleanUrineTest,
        liverFunction,
        kidneyFunction,
        updatedAt: db.serverDate()
      };

      // 根据是否有recordId决定是新增还是更新
      if (recordId) {
        await db.collection('medicalRecords').doc(recordId).update({ data });
      } else {
        data.createdAt = db.serverDate();
        await db.collection('medicalRecords').add({ data });
      }

      wx.hideLoading();
      wx.showToast({ 
        title: recordId ? '更新成功' : '保存成功', 
        icon: 'success' 
      });
      
      setTimeout(() => {
        wx.reLaunch({ url: '/pages/health/health' });
      }, 1500);
    } catch (err) {
      wx.hideLoading();
      wx.showToast({ 
        title: recordId ? '更新失败' : '保存失败', 
        icon: 'none' 
      });
      console.error('操作失败:', err);
    }
  },

  // 返回
  navigateBack() {
    wx.navigateBack();
  }
});
// pages/settings/settings.js
Page({
  data: {
    settings: [
      {
        id: 'account',
        title: '账号与安全',
        icon: '/imgs/settings/account.png',
        items: [
          { name: '账号信息', value: '已绑定微信' },
          { name: '修改密码', value: '' },
          { name: '实名认证', value: '未认证' }
        ]
      },
      {
        id: 'notification',
        title: '通知设置',
        icon: '/imgs/settings/notification.png',
        items: [
          { name: '消息通知', value: '已开启', isSwitch: true, checked: true },
          { name: '预约提醒', value: '已开启', isSwitch: true, checked: true },
          { name: '健康提醒', value: '已开启', isSwitch: true, checked: true }
        ]
      },
      {
        id: 'privacy',
        title: '隐私设置',
        icon: '/imgs/settings/privacy.png',
        items: [
          { name: '位置信息', value: '已开启', isSwitch: true, checked: true },
          { name: '个人资料可见性', value: '仅自己可见' }
        ]
      },
      {
        id: 'general',
        title: '通用',
        icon: '/imgs/settings/general.png',
        items: [
          { name: '清除缓存', value: '' },
          { name: '检查更新', value: '当前版本 1.0.0' },
          { name: '关于我们', value: '' }
        ]
      }
    ]
  },

  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '设置'
    });
  },

  switchChange: function(e) {
    const { sectionIndex, itemIndex } = e.currentTarget.dataset;
    const checked = e.detail.value;
    
    // 更新开关状态
    const settings = this.data.settings;
    settings[sectionIndex].items[itemIndex].checked = checked;
    settings[sectionIndex].items[itemIndex].value = checked ? '已开启' : '已关闭';
    
    this.setData({ settings });
    
    // 这里可以添加实际的设置变更逻辑
    console.log(`设置项 ${settings[sectionIndex].items[itemIndex].name} 已${checked ? '开启' : '关闭'}`);
  },

  navigateToSetting: function(e) {
    const { section, item } = e.currentTarget.dataset;
    
    // 根据不同的设置项跳转到不同的页面或执行不同的操作
    if (section === 'account') {
      if (item.name === '账号信息') {
        wx.navigateTo({ url: '/pages/profile/profile' });
      } else if (item.name === '修改密码') {
        wx.showToast({ title: '修改密码功能开发中', icon: 'none' });
      } else if (item.name === '实名认证') {
        wx.showToast({ title: '实名认证功能开发中', icon: 'none' });
      }
    } else if (section === 'general') {
      if (item.name === '清除缓存') {
        wx.showModal({
          title: '提示',
          content: '确定要清除缓存吗？',
          success: (res) => {
            if (res.confirm) {
              wx.showToast({ title: '缓存已清除', icon: 'success' });
            }
          }
        });
      } else if (item.name === '关于我们') {
        wx.showToast({ title: '关于我们页面开发中', icon: 'none' });
      } else if (item.name === '检查更新') {
        wx.showToast({ title: '已是最新版本', icon: 'success' });
      }
    } else if (section === 'privacy' && item.name === '个人资料可见性') {
      wx.showActionSheet({
        itemList: ['仅自己可见', '好友可见', '所有人可见'],
        success: (res) => {
          const settings = this.data.settings;
          const privacySection = settings.find(s => s.id === 'privacy');
          const visibilityItem = privacySection.items.find(i => i.name === '个人资料可见性');
          
          const options = ['仅自己可见', '好友可见', '所有人可见'];
          visibilityItem.value = options[res.tapIndex];
          
          this.setData({ settings });
        }
      });
    }
  },

  logout: function() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          // 这里可以添加退出登录的逻辑
          wx.showToast({ title: '已退出登录', icon: 'success' });
          setTimeout(() => {
            wx.reLaunch({ url: '/pages/login/login' });
          }, 1500);
        }
      }
    });
  }
})

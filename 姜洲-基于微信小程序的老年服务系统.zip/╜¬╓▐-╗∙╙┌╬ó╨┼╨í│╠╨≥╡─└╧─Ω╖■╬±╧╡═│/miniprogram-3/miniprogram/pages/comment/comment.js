Page({
  data: {
    feedbackType: '请选择类型',
    feedbackContent: '',
    showTypePicker: false,
    feedbackTypes: [
      '功能建议',
      '内容问题',
      '其他反馈'
    ],
    selectedTypeIndex: 0,
    tempSelectedIndex: 0 // 临时存储选择的位置
  },

  onLoad: function(options) {
    // 页面创建时执行
  },

  // 返回first页面
  return: function() {
    wx.reLaunch({
      url: '/pages/first/first'
    });
  },

  // 显示类型选择器
  showTypePicker: function() {
    // 显示时初始化选择位置
    const index = this.data.feedbackTypes.indexOf(this.data.feedbackType);
    this.setData({
      showTypePicker: true,
      tempSelectedIndex: index === -1 ? 0 : index
    });
  },

  // 隐藏类型选择器
  hideTypePicker: function() {
    this.setData({
      showTypePicker: false
    });
  },

  // 类型选择变化
  typeChange: function(e) {
    this.setData({
      tempSelectedIndex: e.detail.value[0]
    });
  },

  // 确认选择类型
  confirmType: function() {
    const selectedType = this.data.feedbackTypes[this.data.tempSelectedIndex];
    this.setData({
      feedbackType: selectedType,
      selectedTypeIndex: this.data.tempSelectedIndex,
      showTypePicker: false
    });
  },

  // 监听反馈内容输入
  onContentInput: function(e) {
    this.setData({
      feedbackContent: e.detail.value
    });
  },

  // 提交反馈
  submitFeedback: function() {
    if (this.data.feedbackType === '请选择类型') {
      wx.showToast({
        title: '请选择反馈类型',
        icon: 'none'
      });
      return;
    }
    
    if (!this.data.feedbackContent.trim()) {
      wx.showToast({
        title: '请输入反馈内容',
        icon: 'none'
      });
      return;
    }
    
    wx.showLoading({
      title: '提交中...',
    });
    
    const userInfo = wx.getStorageSync('userInfo') || {};
    
    const feedbackData = {
      type: this.data.feedbackType,
      content: this.data.feedbackContent,
      createTime: new Date(),
      status: '待处理',
      userId: userInfo._id || '',
      nickName: userInfo.nickName || '匿名用户'
    };
    
    const db = wx.cloud.database();
    db.collection('comment').add({
      data: feedbackData,
      success: res => {
        wx.hideLoading();
        wx.showToast({
          title: '提交成功',
          icon: 'success'
        });
        
        this.setData({
          feedbackType: '请选择类型',
          feedbackContent: ''
        });
        
        setTimeout(() => {
          wx.reLaunch({
            url: '/pages/first/first'
          });
        }, 3000);
      },
      fail: err => {
        wx.hideLoading();
        wx.showToast({
          title: '提交失败',
          icon: 'none'
        });
        console.error('提交反馈失败:', err);
      }
    });
  }
});
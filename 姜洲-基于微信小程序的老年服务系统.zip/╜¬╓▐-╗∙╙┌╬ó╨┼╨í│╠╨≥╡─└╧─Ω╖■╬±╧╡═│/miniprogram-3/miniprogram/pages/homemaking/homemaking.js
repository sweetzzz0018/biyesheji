// pages/homemaking/homemaking.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userId: '',
    appointments: [],
    isLoading: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const app = getApp();
    if (app.globalData.userInfo && app.globalData.userInfo.openid) {
      this.loadUserId(app.globalData.userInfo.openid);
    } else {
      // 监听用户信息变化
      app.userInfoReadyCallback = (userInfo) => {
        this.loadUserId(userInfo.openid);
      };
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    if (this.data.userId) {
      this.loadAppointments();
    }

    // 检查是否需要刷新
    const needRefresh = wx.getStorageSync('homemaking_need_refresh');
    if (needRefresh) {
      // 清除标记
      wx.removeStorageSync('homemaking_need_refresh');
      // 刷新数据
      this.loadAppointments();
    }
  },

  // 通过 openid 查询 userId
  async loadUserId(openid) {
    const db = wx.cloud.database();
    try {
      const res = await db.collection('users').where({ openid }).get();

      if (res.data.length > 0) {
        const userId = res.data[0]._id; // 获取 userId
        this.setData({ userId });

        // 加载预约列表
        this.loadAppointments();
      } else {
        console.error('未找到用户');
        wx.showToast({
          title: '未找到用户',
          icon: 'none',
        });
      }
    } catch (err) {
      console.error('加载用户信息失败:', err);
      wx.showToast({
        title: '加载用户信息失败',
        icon: 'none',
      });
    }
  },

  // 加载预约列表
  async loadAppointments() {
    if (this.data.isLoading) return;
    this.setData({ isLoading: true });

    wx.showLoading({ title: '加载中...' });

    try {
      const db = wx.cloud.database();
      const _ = db.command;

      // 查询当前用户的所有家政服务预约
      const res = await db.collection('homemaking')
        .where({
          userId: this.data.userId
        })
        .orderBy('createTime', 'desc')
        .get();

      // 格式化时间
      const appointments = res.data.map(item => ({
        ...item,
        formattedCreateTime: this.formatDate(item.createTime)
      }));

      this.setData({ appointments });
    } catch (err) {
      console.error('加载预约失败:', err);
      wx.showToast({
        title: '加载预约失败',
        icon: 'none'
      });
    } finally {
      this.setData({ isLoading: false });
      wx.hideLoading();
    }
  },

  // 格式化日期
  formatDate(timestamp) {
    if (!timestamp) return '';

    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hour = date.getHours().toString().padStart(2, '0');
    const minute = date.getMinutes().toString().padStart(2, '0');

    return `${year}-${month}-${day} ${hour}:${minute}`;
  },

  // 查看预约详情
  viewAppointmentDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/homemakingDetail/homemakingDetail?id=${id}`
    });
  },

  // 防止事件冒泡
  stopPropagation() {
    return;
  },

  // 取消预约
  cancelAppointment(e) {
    const id = e.currentTarget.dataset.id;

    wx.showModal({
      title: '确认取消',
      content: '确定要取消这个家政服务预约吗？',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '取消中...' });

          try {
            const db = wx.cloud.database();
            await db.collection('homemaking').doc(id).update({
              data: {
                status: '已取消',
                updateTime: db.serverDate()
              }
            });

            wx.showToast({
              title: '取消成功',
              icon: 'success'
            });

            // 重新加载预约列表
            this.loadAppointments();
          } catch (err) {
            console.error('取消预约失败:', err);
            wx.showToast({
              title: '取消失败',
              icon: 'none'
            });
          } finally {
            wx.hideLoading();
          }
        }
      }
    });
  },

  // 前往家政服务类型页面
  goToAddAppointment() {
    wx.navigateTo({
      url: '/pages/homemakingServices/homemakingServices'
    });
  }
})
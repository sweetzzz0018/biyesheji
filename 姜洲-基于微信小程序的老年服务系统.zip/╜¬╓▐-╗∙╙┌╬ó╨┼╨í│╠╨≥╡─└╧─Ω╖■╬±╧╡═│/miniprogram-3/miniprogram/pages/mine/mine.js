Page({
  data: {
    display: 'displaynone',
    order: [
      {
        img: "/imgs/mine/1.png",
        text: "健康数据",
      },
      {
        img: "/imgs/mine/2.png",
        text: "我的预订",
      },
      {
        img: "/imgs/mine/3.png",
        text: "医疗记录",
      },
    ],
    functions: [
      {
        name: "one",
        img: "/imgs/mine/4.png",
        text: "我的发布",
        src: "",
      },
      {
        name: "two",
        img: "/imgs/mine/5.png",
        text: "服务卡包",
        src: "",
      },
      {
        name: "three",
        img: "/imgs/mine/6.png",
        text: "联系我们",
        src: "",
      },
      {
        name: "four",
        img: "/imgs/mine/7.png",
        text: "意见反馈",
        src: "",
      },
      {
        name: "five",
        img: "/imgs/mine/8.png",
        text: "设置",
        src: "",
      },
      {
        name: "six",
        img: "/imgs/mine/9.png",
        text: "个人信息",
        src: "",
      },
    ],
    userdata: {
      avatarUrl: "/imgs/index/default-avatar.png",  // 用户头像
      nickName: "微信用户",  // 用户昵称
    },
  },

  // 获取用户信息
  loadUserData: function() {
    const db = wx.cloud.database();
    const app = getApp();
    const openid = app.globalData.openid;  // 获取存储在全局变量中的openid

    if (!openid) {
      console.log('未找到openid，使用默认用户信息');
      this.setData({
        'userdata.avatarUrl': "/imgs/index/default-avatar.png",
        'userdata.nickName': "微信用户",
      });
      return;
    }

    // 1. 直接从userdata集合通过openid查询
    db.collection('userdata').where({
      openid: openid
    }).get()
      .then(res => {
        if (res.data && res.data.length > 0) {
          const userData = res.data[0];  // 假设openid唯一，获取第一个匹配的数据

          // 如果用户没有头像，使用默认头像
          const userAvatar = userData.avatarUrl || "/imgs/index/default-avatar.png";

          // 如果没有设置名字，使用微信的nickName作为默认名字
          const userNickName = userData.nickName || "微信用户";

          this.setData({
            'userdata.avatarUrl': userAvatar,
            'userdata.nickName': userNickName,
          });
          console.log('从userdata获取到用户信息:', userNickName);
        } else {
          console.log('未找到用户数据，尝试通过userId查询');
          // 如果通过openid找不到，尝试通过userId查询
          this.loadUserDataByUserId(openid);
        }
      })
      .catch(err => {
        console.error('加载用户数据失败:', err);
        // 出错时使用默认值
        this.setData({
          'userdata.avatarUrl': "/imgs/index/default-avatar.png",
          'userdata.nickName': "微信用户",
        });
      });
  },

  // 通过userId查询userdata
  loadUserDataByUserId: function(openid) {
    const db = wx.cloud.database();

    // 先从users集合获取userId
    db.collection('users').where({
      openid: openid
    }).get()
      .then(res => {
        if (res.data && res.data.length > 0) {
          const userId = res.data[0]._id;

          // 使用userId查询userdata集合
          db.collection('userdata').where({
            userId: userId
          }).get()
            .then(userdataRes => {
              if (userdataRes.data && userdataRes.data.length > 0) {
                const userData = userdataRes.data[0];

                // 如果用户没有头像，使用默认头像
                const userAvatar = userData.avatarUrl || "/imgs/index/default-avatar.png";

                // 如果没有设置名字，使用微信的nickName作为默认名字
                const userNickName = userData.nickName || "微信用户";

                this.setData({
                  'userdata.avatarUrl': userAvatar,
                  'userdata.nickName': userNickName,
                });
                console.log('通过userId从userdata获取到用户信息:', userNickName);
              } else {
                // 如果在userdata中找不到，使用users集合中的信息
                this.loadUserDataFromUsers(openid);
              }
            })
            .catch(err => {
              console.error('通过userId从userdata获取用户信息失败:', err);
              // 如果出错，尝试从users集合获取
              this.loadUserDataFromUsers(openid);
            });
        } else {
          console.log('未找到用户ID，尝试从users集合获取');
          // 如果找不到userId，尝试从users集合获取
          this.loadUserDataFromUsers(openid);
        }
      })
      .catch(err => {
        console.error('获取用户ID失败:', err);
        // 如果出错，尝试从users集合获取
        this.loadUserDataFromUsers(openid);
      });
  },

  // 从users集合获取用户信息
  loadUserDataFromUsers: function(openid) {
    const db = wx.cloud.database();

    db.collection('users').where({
      openid: openid
    }).get()
      .then(res => {
        if (res.data && res.data.length > 0) {
          const userData = res.data[0];

          // 如果用户没有头像，使用默认头像
          const userAvatar = userData.avatarUrl || "/imgs/index/default-avatar.png";

          // 如果没有设置名字，使用微信的nickName作为默认名字
          const userNickName = userData.nickName || "微信用户";

          this.setData({
            'userdata.avatarUrl': userAvatar,
            'userdata.nickName': userNickName,
          });
          console.log('从users集合获取到用户信息:', userNickName);
        } else {
          console.log('未找到用户信息，使用默认值');
          // 如果在users中也找不到，使用默认值
          this.setData({
            'userdata.avatarUrl': "/imgs/index/default-avatar.png",
            'userdata.nickName': "微信用户",
          });
        }
      })
      .catch(err => {
        console.error('从users集合加载用户数据失败:', err);
        // 出错时使用默认值
        this.setData({
          'userdata.avatarUrl': "/imgs/index/default-avatar.png",
          'userdata.nickName': "微信用户",
        });
      });
  },

  goProfile: function() {
    wx.navigateTo({
      url: '/pages/profile/profile', // 请确保这个路径是你的个人资料页路径
    });
  },

  order: function(e) {
    const index = e.currentTarget.dataset.index;
    let url = '';

    // 根据点击的按钮跳转到不同页面
    switch(index) {
      case 0: // 健康数据
        url = '/pages/health/health';
        break;
      case 1: // 我的预订
        // 这里可以跳转到一个包含所有预约的页面，或者分别跳转到医院和家政预约
        wx.showActionSheet({
          itemList: ['医院预约', '家政服务'],
          success: (res) => {
            if (res.tapIndex === 0) {
              wx.navigateTo({ url: '/pages/hospital/hospital' });
            } else if (res.tapIndex === 1) {
              wx.navigateTo({ url: '/pages/homemaking/homemaking' });
            }
          }
        });
        return; // 直接返回，不执行后面的跳转
      case 2: // 医疗记录
        // 跳转到体检记录页面
        url = '/pages/health/health';
        break;
    }

    if (url) {
      // 如果是 tabBar 页面，使用 switchTab
      if (url === '/pages/health/health' || url === '/pages/moments/moments' || url === '/pages/first/first') {
        wx.switchTab({ url });
      } else {
        wx.navigateTo({ url });
      }
    }
  },

  function: function(e) {
    const index = e.currentTarget.dataset.index;
    let url = '';

    // 根据点击的按钮跳转到不同页面
    switch(index) {
      case 0: // 我的发布
        url = '/pages/post/post';
        break;
      case 1: // 服务卡包
        url = '/pages/serviceCards/serviceCards';
        break;
      case 2: // 联系我们
        url = '/pages/help/help';
        break;
      case 3: // 意见反馈
        url = '/pages/comment/comment';
        break;
      case 4: // 设置
        url = '/pages/settings/settings';
        break;
      case 5: // 个人信息
        url = '/pages/profile/profile';
        break;
    }

    if (url) {
      wx.navigateTo({ url });
    } else {
      // 如果没有对应页面，提示用户
      wx.showToast({
        title: '功能开发中',
        icon: 'none'
      });
    }
  },

  goperson: function() {
    wx.navigateTo({
      url: '/pages/profile/profile',
    });
  },

  onLoad(options) {
    this.loadUserData();  // 加载用户信息
  },

  onReady() {},

  onShow() {},

  onHide() {},

  onUnload() {},

  onPullDownRefresh() {},

  onReachBottom() {},

  onShareAppMessage() {},
});

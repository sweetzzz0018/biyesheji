// 首页 first.js
Page({
  data: {
    shouye: "首页",
    find: "找你想要的",
    gonggao: "主打功能",
    share: "致力让每个老人享受到优质服务",
    leyuan: "最新公告",
    talk: "随时了解身边大事！",
    tabbarlistsrc: [
      "/pages/first/first",
      "/pages/health/health",
      "/pages/moments/moments",
      "/pages/mine/mine"
    ],
    lunbo: [
      "../../imgs/lunbo/one.jpg",
      "../../imgs/lunbo/two.jpg",
      "../../imgs/lunbo/three.jpg",
      "../../imgs/lunbo/four.jpg",
    ],
    lists: [
      {
        img: "../../imgs/index/healthtwo.png",
        text: "我的健康",
        src: '/pages/health/health'
      },
      {
        img: "../../imgs/index/Medical.png",
        text: "医院预约",
        src: '/pages/hospital/hospital'
      },
      {
        img: "../../imgs/index/homemaking.png",
        text: "家政服务",
        src: '/pages/homemaking/homemaking'
      },
      {
        img: "../../imgs/index/momentstwo.png",
        text: "文娱活动",
        src: '/pages/moments/moments'
      },
      {
        img: "../../imgs/index/comment.png",
        text: "反馈",
        src: '/pages/comment/comment'
      },
      {
        img: "../../imgs/index/call.png",
        text: "帮助",
        src: '/pages/help/help'
      },
    ],
    announcements: [] // 公告数据
  },

  onLoad() {
    this.loadAnnouncements();
  },

  onShow() {
    this.loadAnnouncements();  // 每次返回首页时重新加载公告数据
  },

  // 加载公告数据
  loadAnnouncements() {
    const db = wx.cloud.database();
    db.collection('announcements')
      .orderBy('createTime', 'desc')
      .get()
      .then(res => {
        this.setData({
          announcements: res.data.map(item => ({
            ...item,
            formattedTime: this.formatTime(item.createTime)
          }))
        });
      })
      .catch(err => {
        console.error('加载公告失败:', err);
      });
  },

  // 时间格式化方法
  formatTime(timestamp) {
    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const hours = date.getHours().toString().padStart(2, '0');
    const minutes = date.getMinutes().toString().padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}`;
  },

  // 跳转到公告详情页面
  viewAnnouncementDetail: function (e) {
    const announcementId = e.currentTarget.dataset.id; // 获取公告ID
    wx.navigateTo({
      url: `/pages/announcementDetails/announcementDetails?id=${announcementId}`,
    });
  },

  // 原有方法保持不变
  showpet: function (e) {
    if (this.data.tabbarlistsrc.indexOf(e.currentTarget.dataset.src) != -1) {
      wx.switchTab({
        url: e.currentTarget.dataset.src,
      });
    } else {
      wx.navigateTo({
        url: e.currentTarget.dataset.src,
      });
    }
  },
});

Page({
  data: {
    userInfo: {}, // 用户信息
    healthProfile: {}, // 健康档案
    medicalRecords: [], // 体检记录
    healthReminders: [], // 健康提醒
    coverUrl: '/imgs/default-cover.jpg', // 默认封面图
  },

  onLoad() {
    const app = getApp();
    console.log('健康页面加载，全局数据:', app.globalData);

    if (app.globalData.userInfo) {
      const openid = app.globalData.userInfo.openid;
      console.log('从userInfo获取openid:', openid);
      this.loadUserId(openid);
    } else if (app.globalData.openid) {
      console.log('直接使用全局openid:', app.globalData.openid);
      this.loadUserId(app.globalData.openid);
    } else {
      console.log('未找到用户登录信息，需要登录');
      wx.showToast({
        title: '请先登录',
        icon: 'none',
        duration: 2000
      });
      setTimeout(() => {
        wx.navigateTo({
          url: '/pages/login/login'
        });
      }, 2000);
    }
  },

  onShow() {
    const { userId } = this.data;
    if (userId) {
      this.loadUserInfo(userId);
      this.loadHealthProfile(userId);
      this.loadMedicalRecords(userId);
      this.loadHealthReminders(userId);
    }
  },

  async loadUserId(openid) {
    const db = wx.cloud.database();
    try {
      console.log('正在查询users集合，openid:', openid);
      const res = await db.collection('users').where({ openid }).get();
      console.log('查询结果:', res.data);

      if (res.data.length > 0) {
        const userId = res.data[0]._id; 
        console.log('找到用户ID:', userId);
        this.setData({ userId });

        this.loadUserInfo(userId);

        // 加载健康档案
        this.loadHealthProfile(userId);

        // 加载体检记录
        this.loadMedicalRecords(userId);

        // 加载健康提醒
        this.loadHealthReminders(userId);
      } else {
        console.error('未找到用户');
        // 尝试创建新用户
        if (openid) {
          console.log('尝试创建新用户');
          try {
            const result = await db.collection('users').add({
              data: {
                openid: openid,
                name: '未设置',
                age: '未设置',
                gender: '未设置',
                createTime: new Date()
              }
            });
            console.log('创建新用户成功:', result);
            // 创建成功后重新加载
            this.loadUserId(openid);
            return;
          } catch (addErr) {
            console.error('创建用户失败:', addErr);
          }
        }

        wx.showToast({
          title: '未找到用户',
          icon: 'none',
        });
      }
    } catch (err) {
      console.error('加载用户信息失败:', err);
      wx.showToast({
        title: '加载用户信息失败',
        icon: 'none',
      });
    }
  },

  // 加载用户信息
  async loadUserInfo(userId) {
    const db = wx.cloud.database();
    try {
      // 从 users 集合中获取用户信息
      const res = await db.collection('users').doc(userId).get();
      let userInfo = res.data;

      // 尝试从 userdata 集合中获取详细信息（与社区页面保持一致）
      try {
        // 使用userId查询userdata集合
        const userdataRes = await db.collection('userdata').where({ userId: userId }).get();

        if (userdataRes.data.length > 0) {
          // 如果在userdata中找到了用户信息，使用其中的昵称、头像、年龄和性别
          const userData = userdataRes.data[0];
          userInfo.nickName = userData.nickName || userInfo.nickName || '微信用户';
          userInfo.avatarUrl = userData.avatarUrl || userInfo.avatarUrl || '/imgs/default-avatar.png';
          userInfo.coverUrl = userData.coverUrl || userInfo.coverUrl || '/imgs/default-cover.jpg';
          userInfo.age = userData.age || userInfo.age || '未设置';
          userInfo.gender = userData.gender || userInfo.gender || '未设置';
          console.log('从userdata获取到用户信息:', userInfo.nickName, userInfo.age, userInfo.gender);
        } else {
          // 如果通过userId找不到，尝试通过openid查询
          const app = getApp();
          const openid = app.globalData.openid || (app.globalData.userInfo ? app.globalData.userInfo.openid : null);

          if (openid) {
            const openidRes = await db.collection('userdata').where({ openid: openid }).get();
            if (openidRes.data.length > 0) {
              const userData = openidRes.data[0];
              userInfo.nickName = userData.nickName || userInfo.nickName || '微信用户';
              userInfo.avatarUrl = userData.avatarUrl || userInfo.avatarUrl || '/imgs/default-avatar.png';
              userInfo.coverUrl = userData.coverUrl || userInfo.coverUrl || '/imgs/default-cover.jpg';
              userInfo.age = userData.age || userInfo.age || '未设置';
              userInfo.gender = userData.gender || userInfo.gender || '未设置';
              console.log('通过openid从userdata获取到用户信息:', userInfo.nickName, userInfo.age, userInfo.gender);
            }
          }
        }

        this.setData({ userInfo });
      } catch (userdataErr) {
        console.error('从userdata获取用户信息失败:', userdataErr);
        this.setData({ userInfo });
      }
    } catch (err) {
      console.error('从users集合加载用户信息失败:', err);

      // 尝试从 userdata 集合中获取（兼容旧数据）
      try {
        const app = getApp();
        const openid = app.globalData.openid || (app.globalData.userInfo ? app.globalData.userInfo.openid : null);

        let query = {};
        if (userId) {
          query.userId = userId;
        } else if (openid) {
          query.openid = openid;
        }

        const oldRes = await db.collection('userdata').where(query).get();
        if (oldRes.data.length > 0) {
          this.setData({ userInfo: oldRes.data[0] });
        } else {
          wx.showToast({
            title: '加载用户信息失败',
            icon: 'none',
          });
        }
      } catch (oldErr) {
        wx.showToast({
          title: '加载用户信息失败',
          icon: 'none',
        });
      }
    }
  },

  // 导航到个人资料页面
  navigateToProfile() {
    wx.navigateTo({
      url: '/pages/profile/profile'
    });
  },

  // 加载健康档案
  async loadHealthProfile(userId) {
    const db = wx.cloud.database();
    try {
      console.log('正在查询健康档案，userId:', userId);
      const res = await db.collection('healthProfiles').where({ userId }).get(); // 使用查到的 userId
      console.log('健康档案查询结果:', res.data);

      if (res.data.length > 0) {
        this.setData({ healthProfile: res.data[0] });
      } else {
        console.log('未找到健康档案，尝试创建默认档案');
        // 创建默认健康档案
        try {
          const result = await db.collection('healthProfiles').add({
            data: {
              userId: userId,
              height: '',
              weight: '',
              medicalHistory: '',
              createTime: new Date()
            }
          });
          console.log('创建默认健康档案成功:', result);
          // 重新加载健康档案
          this.loadHealthProfile(userId);
        } catch (addErr) {
          console.error('创建健康档案失败:', addErr);
        }
      }
    } catch (err) {
      console.error('加载健康档案失败:', err);
      wx.showToast({
        title: '加载健康档案失败',
        icon: 'none',
      });
    }
  },


  viewMedicalRecordDetail(e) {
    const recordId = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/medicalRecordDetail/medicalRecordDetail?id=${recordId}`,
    });
  },

  // 加载体检记录
  async loadMedicalRecords(userId) {
    const db = wx.cloud.database();
    try {
      const res = await db.collection('medicalRecords').where({ userId }).get(); // 使用查到的 userId
      this.setData({ medicalRecords: res.data });
    } catch (err) {
      console.error('加载体检记录失败:', err);
      wx.showToast({
        title: '加载体检记录失败',
        icon: 'none',
      });
    }
  },

  // 加载健康提醒
  async loadHealthReminders(userId) {
    const db = wx.cloud.database();
    try {
      const res = await db.collection('healthReminders').where({ userId }).get(); // 使用查到的 userId
      this.setData({ healthReminders: res.data });
    } catch (err) {
      console.error('加载健康提醒失败:', err);
      wx.showToast({
        title: '加载健康提醒失败',
        icon: 'none',
      });
    }
  },

  // 跳转到编辑页面
  navigateToEditPage(e) {
    const { type } = e.currentTarget.dataset;
    let url = '';

    switch (type) {
      case 'healthProfile':
        url = '/pages/editHealthProfile/editHealthProfile';
        break;
      case 'medicalRecord':
        url = '/pages/editMedicalRecord/editMedicalRecord';
        break;
      case 'healthReminder':
        url = '/pages/editHealthReminder/editHealthReminder';
        break;
      default:
        console.error('未知类型:', type);
        return;
    }

    wx.navigateTo({
      url,
      success: () => {
        // 跳转成功后刷新当前页面数据
        this.onShow();
      }
    });
  },

  // 切换健康提醒状态
  async toggleReminder(e) {
    const index = e.currentTarget.dataset.index;
    const reminder = this.data.healthReminders[index];
    const enabled = e.detail.value;

    wx.showLoading({
      title: '更新中...',
    });

    try {
      const db = wx.cloud.database();
      await db.collection('healthReminders').doc(reminder._id).update({
        data: { enabled },
      });

      // 更新本地数据
      const healthReminders = this.data.healthReminders;
      healthReminders[index].enabled = enabled;
      this.setData({ healthReminders });

      wx.hideLoading();
      wx.showToast({
        title: '更新成功',
        icon: 'success',
      });
    } catch (err) {
      wx.hideLoading();
      wx.showToast({
        title: '更新失败',
        icon: 'none',
      });
      console.error('更新失败:', err);
    }
  },
});

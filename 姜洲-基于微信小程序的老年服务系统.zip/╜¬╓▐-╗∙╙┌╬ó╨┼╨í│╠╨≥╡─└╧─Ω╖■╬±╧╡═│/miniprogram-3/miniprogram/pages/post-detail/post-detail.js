const db = wx.cloud.database()
const _ = db.command

Page({
  data: {
    post: {},
    comment: '',
    isLoading: true,
    comments: [] // 存储评论列表
  },

  onLoad(options) {
    // 初始化静默openid
    wx.cloud.callFunction({ name: 'getOpenId' }).then(res => {
      this.setData({ currentOpenid: res.result.openid })
    })

    if (options.id) {
      this.loadPost(options.id)
    } else {
      wx.showToast({ title: '动态ID缺失', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 1500)
    }
  },

  // 加载动态详情
  async loadPost(id) {
    this.setData({ isLoading: true })
    try {
      const res = await db.collection('moments').doc(id).get()

      // 确保likes和comments是数组
      const post = {
        ...res.data,
        likes: res.data.likes || [],
        comments: res.data.comments || []
      }

      // 尝试更新用户信息
      if (post.userId) {
        try {
          // 使用userId从userdata集合获取详细信息
          const userdataRes = await db.collection('userdata').where({ userId: post.userId }).get()

          if (userdataRes.data.length > 0) {
            // 如果在userdata中找到了用户信息，更新post中的用户信息
            post.user = {
              ...post.user,
              nickName: userdataRes.data[0].nickName || post.user?.nickName || '微信用户',
              avatarUrl: userdataRes.data[0].avatarUrl || post.user?.avatarUrl || '/imgs/default-avatar.png'
            }
            console.log('从userdata更新动态用户信息:', post.user.nickName)
          }
        } catch (userdataErr) {
          console.error('从userdata获取用户信息失败:', userdataErr)
        }
      } else if (post.user && post.user.openid) {
        // 如果没有userId但有openid，尝试通过openid查询
        try {
          const userdataRes = await db.collection('userdata').where({ openid: post.user.openid }).get()

          if (userdataRes.data.length > 0) {
            // 如果在userdata中找到了用户信息，更新post中的用户信息
            post.user = {
              ...post.user,
              nickName: userdataRes.data[0].nickName || post.user.nickName || '微信用户',
              avatarUrl: userdataRes.data[0].avatarUrl || post.user.avatarUrl || '/imgs/default-avatar.png'
            }
            console.log('通过openid从userdata更新动态用户信息:', post.user.nickName)
          }
        } catch (userdataErr) {
          console.error('通过openid从userdata获取用户信息失败:', userdataErr)
        }
      }

      // 更新评论中的用户信息
      const comments = await Promise.all(post.comments.map(async comment => {
        let updatedComment = {
          ...comment,
          formattedTime: this.formatTime(comment.createTime)
        }

        // 如果评论有用户openid，尝试更新用户信息
        if (comment.user && comment.user.openid) {
          try {
            // 先尝试通过openid直接从userdata获取
            const userdataRes = await db.collection('userdata').where({ openid: comment.user.openid }).get()

            if (userdataRes.data.length > 0) {
              updatedComment.user = {
                ...comment.user,
                nickName: userdataRes.data[0].nickName || comment.user.nickName || '微信用户',
                avatarUrl: userdataRes.data[0].avatarUrl || comment.user.avatarUrl || '/imgs/default-avatar.png'
              }
              console.log('从userdata更新评论用户信息:', updatedComment.user.nickName)
            }
          } catch (err) {
            console.error('更新评论用户信息失败:', err)
          }
        }

        return updatedComment
      }))

      this.setData({
        post: post,
        comments: comments,
        isLoading: false
      })
    } catch (err) {
      this.handleError('加载失败', err)
    }
  },

  // 格式化时间
  formatTime(timestamp) {
    if (!timestamp) return ''

    const date = new Date(timestamp)
    const now = new Date()
    const diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) {
      return `今天 ${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`
    } else if (diffDays === 1) {
      return `昨天 ${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`
    } else {
      return `${date.getMonth()+1}月${date.getDate()}日 ${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`
    }
  },

  async toggleLike() {
    try {
      // 获取用户的openid（无需登录）
      const { result } = await wx.cloud.callFunction({
        name: 'getOpenId'
      })
      const currentOpenid = result.openid

      // 检查是否已点赞
      const { post } = this.data
      const isLiked = post.likes && post.likes.includes(currentOpenid)

      if (isLiked) {
        wx.showToast({ title: '您已经点过赞了', icon: 'none' })
        return
      }

      // 执行点赞
      await db.collection('moments').doc(post._id).update({
        data: {
          likes: _.push(currentOpenid)
        }
      })

      // 更新本地数据
      const updatedPost = {
        ...post,
        likes: [...post.likes, currentOpenid]
      }

      this.setData({ post: updatedPost })

      // 设置刷新标记，通知社区页面需要刷新
      wx.setStorageSync('moments_need_refresh', true)

      wx.showToast({ title: '点赞成功', icon: 'success' })
    } catch (err) {
      this.handleError('操作失败', err)
    }
  },

  // 提交评论（无需限制）
  async submitComment() {
    const { comment, post } = this.data
    if (!comment.trim()) {
      wx.showToast({ title: '评论不能为空', icon: 'none' })
      return
    }

    wx.showLoading({ title: '提交中...' })
    try {
      // 获取当前用户信息
      const { result } = await wx.cloud.callFunction({
        name: 'getOpenId'
      })
      const openid = result.openid

      // 获取用户信息
      let userInfo = { nickName: '微信用户', avatarUrl: '/imgs/default-avatar.png' }

      try {
        // 1. 先从users集合获取userId
        const userRes = await db.collection('users').where({ openid }).get()

        if (userRes.data.length > 0) {
          const userId = userRes.data[0]._id

          // 2. 使用userId从userdata集合获取详细信息
          try {
            const userdataRes = await db.collection('userdata').where({ userId }).get()

            if (userdataRes.data.length > 0) {
              // 如果在userdata中找到了用户信息，使用其中的昵称和头像
              userInfo = {
                nickName: userdataRes.data[0].nickName || '微信用户',
                avatarUrl: userdataRes.data[0].avatarUrl || '/imgs/default-avatar.png',
                openid
              }
              console.log('从userdata获取到用户信息:', userInfo.nickName)
            } else {
              // 如果在userdata中找不到，使用users集合中的信息
              userInfo = {
                nickName: userRes.data[0].nickName || '微信用户',
                avatarUrl: userRes.data[0].avatarUrl || '/imgs/default-avatar.png',
                openid
              }
            }
          } catch (userdataErr) {
            console.error('从userdata获取用户信息失败:', userdataErr)
            // 使用users集合中的信息作为备选
            userInfo = {
              nickName: userRes.data[0].nickName || '微信用户',
              avatarUrl: userRes.data[0].avatarUrl || '/imgs/default-avatar.png',
              openid
            }
          }
        } else {
          // 如果在users集合中找不到，尝试直接从userdata集合通过openid查询
          try {
            const directUserdataRes = await db.collection('userdata').where({ openid }).get()
            if (directUserdataRes.data.length > 0) {
              userInfo = {
                nickName: directUserdataRes.data[0].nickName || '微信用户',
                avatarUrl: directUserdataRes.data[0].avatarUrl || '/imgs/default-avatar.png',
                openid
              }
              console.log('通过openid从userdata获取到用户信息:', userInfo.nickName)
            }
          } catch (directErr) {
            console.error('通过openid从userdata获取用户信息失败:', directErr)
          }
        }
      } catch (userErr) {
        console.error('获取用户信息失败:', userErr)
      }

      // 添加评论
      await db.collection('moments').doc(post._id).update({
        data: {
          comments: _.push({
            content: comment,
            user: userInfo,
            createTime: db.serverDate()
          })
        }
      })

      wx.showToast({ title: '评论成功' })
      this.setData({ comment: '' })
      this.loadPost(post._id)

      // 设置刷新标记，通知社区页面需要刷新
      wx.setStorageSync('moments_need_refresh', true)
    } catch (err) {
      this.handleError('评论失败', err)
    } finally {
      wx.hideLoading()
    }
  },

  // 错误处理
  handleError(msg, err) {
    console.error(msg, err)
    wx.showToast({ title: msg, icon: 'none' })
    this.setData({ isLoading: false })
  },

  previewImage(e) {
    wx.previewImage({
      current: e.currentTarget.dataset.current,
      urls: e.currentTarget.dataset.urls
    })
  },

  inputComment(e) {
    this.setData({ comment: e.detail.value })
  }
})
Page({
  data: {
    record: {
      bloodTest: {},
      urineTest: {},
      liverFunction: {},
      kidneyFunction: {},
      images: []
    },
    recordId: '',
    foldStatus: {
      bloodTest: false,
      urineTest: false,
      liverFunction: false,
      kidneyFunction: false,
      images: false
    },
    bmiEvaluation: ''
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ recordId: options.id });
      this.loadRecordDetail(options.id);
    }
  },

  // 返回上一页
  goBack() {
    wx.navigateBack();
  },

  // 预览图片
  previewImage(e) {
    wx.previewImage({
      current: e.currentTarget.dataset.url,
      urls: this.data.record.images
    });
  },

  // 切换折叠状态
  toggleSection(e) {
    const section = e.currentTarget.dataset.section;
    this.setData({
      [`foldStatus.${section}`]: !this.data.foldStatus[section]
    });
  },

  // BMI评价方法
  getBMIEvaluation(bmi) {
    if (!bmi) return '';
    bmi = parseFloat(bmi);
    if (isNaN(bmi)) return '';
    if (bmi < 18.5) return "偏瘦";
    if (bmi < 24) return "正常";
    if (bmi < 28) return "超重";
    return "肥胖";
  },

  // 加载详细记录
  async loadRecordDetail(recordId) {
    wx.showLoading({ title: '加载中...' });

    try {
      const db = wx.cloud.database();
      const res = await db.collection('medicalRecords').doc(recordId).get();

      if (res.data) {
        // 处理图片临时URL
        let images = [];
        if (res.data.images && res.data.images.length > 0) {
          const fileRes = await wx.cloud.getTempFileURL({
            fileList: res.data.images
          });
          images = fileRes.fileList.map(file => file.tempFileURL);
        }

        this.setData({
          record: {
            ...res.data,
            images: images
          },
          bmiEvaluation: this.getBMIEvaluation(res.data.bmi)
        });
      } else {
        wx.showToast({ title: '记录不存在', icon: 'none' });
        setTimeout(() => wx.navigateBack(), 1500);
      }
    } catch (err) {
      console.error('加载记录失败:', err);
      wx.showToast({ title: '加载失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  // 显示删除确认对话框
  showDeleteConfirm() {
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这条体检记录吗？删除后无法恢复',
      confirmColor: '#ff4d4f',
      success: res => {
        if (res.confirm) {
          this.deleteRecord();
        }
      }
    });
  },

  // 删除记录
  async deleteRecord() {
    wx.showLoading({ title: '删除中...' });

    try {
      const db = wx.cloud.database();
      await db.collection('medicalRecords').doc(this.data.recordId).remove();

      wx.showToast({ title: '删除成功', icon: 'success' });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    } catch (err) {
      console.error('删除失败:', err);
      wx.showToast({ title: '删除失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  }
});
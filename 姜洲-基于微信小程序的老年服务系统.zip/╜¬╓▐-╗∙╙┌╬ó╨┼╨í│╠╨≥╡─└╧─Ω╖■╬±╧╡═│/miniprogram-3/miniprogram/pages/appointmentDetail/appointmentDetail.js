Page({
  data: {
    appointmentId: '',
    appointment: {},
    statusDescription: '',
    maskedIdCard: ''
  },

  onLoad(options) {
    if (options.id) {
      this.setData({ appointmentId: options.id });
      this.loadAppointmentDetail(options.id);
    }
  },



  // 加载预约详情
  async loadAppointmentDetail(appointmentId) {
    wx.showLoading({ title: '加载中...' });

    try {
      const db = wx.cloud.database();
      const res = await db.collection('medical').doc(appointmentId).get();

      if (res.data) {
        // 处理身份证号码掩码
        let maskedIdCard = '';
        if (res.data.patientIdCard) {
          const idCard = res.data.patientIdCard;
          maskedIdCard = idCard.length > 10
            ? idCard.substring(0, 6) + '********' + idCard.substring(14)
            : idCard;
        }

        // 设置状态描述
        let statusDescription = '';
        switch (res.data.status) {
          case '待确认':
            statusDescription = '您的预约正在等待医院确认，请耐心等待';
            break;
          case '已确认':
            statusDescription = '医院已确认您的预约，请按时前往就诊';
            break;
          case '已完成':
            statusDescription = '您的预约已完成，感谢您的信任';
            break;
          case '已取消':
            statusDescription = '您的预约已取消';
            break;
          default:
            statusDescription = '预约状态未知';
        }

        this.setData({
          appointment: res.data,
          maskedIdCard,
          statusDescription
        });
      } else {
        wx.showToast({ title: '预约不存在', icon: 'none' });
        setTimeout(() => wx.navigateBack(), 1500);
      }
    } catch (err) {
      console.error('加载预约详情失败:', err);
      wx.showToast({ title: '加载失败', icon: 'none' });
    } finally {
      wx.hideLoading();
    }
  },

  // 取消预约
  cancelAppointment() {
    wx.showModal({
      title: '确认取消',
      content: '确定要取消这个预约吗？',
      success: async (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '取消中...' });

          try {
            const db = wx.cloud.database();
            await db.collection('medical').doc(this.data.appointmentId).update({
              data: {
                status: '已取消',
                updateTime: db.serverDate()
              }
            });

            // 更新本地数据
            const appointment = { ...this.data.appointment, status: '已取消' };
            this.setData({
              appointment,
              statusDescription: '您的预约已取消'
            });

            // 设置刷新标记
            wx.setStorageSync('hospital_need_refresh', true);

            wx.hideLoading();
            wx.showToast({
              title: '取消成功',
              icon: 'success'
            });
          } catch (err) {
            wx.hideLoading();
            console.error('取消预约失败:', err);
            wx.showToast({
              title: '取消失败',
              icon: 'none'
            });
          }
        }
      }
    });
  }
});

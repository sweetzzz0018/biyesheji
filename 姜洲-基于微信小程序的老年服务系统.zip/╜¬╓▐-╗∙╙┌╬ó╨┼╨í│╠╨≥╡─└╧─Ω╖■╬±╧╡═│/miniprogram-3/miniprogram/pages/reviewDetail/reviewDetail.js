// pages/reviewDetail/reviewDetail.js
Page({
  data: {
    review: {}, // 当前反馈详情
    status: 'pending', // 当前状态
    id: '' // 反馈ID
  },

  onLoad(options) {
    this.setData({
      id: options.id
    });
    this.loadReviewDetail();
  },

  // 加载反馈详情
  loadReviewDetail() {
    wx.showLoading({
      title: '加载中...',
    });

    const db = wx.cloud.database();
    db.collection('comment')
      .doc(this.data.id)
      .get()
      .then(res => {
        this.setData({
          review: res.data,
          status: res.data.status || 'pending'
        });
        wx.hideLoading();
      })
      .catch(err => {
        console.error('加载反馈详情失败:', err);
        wx.hideLoading();
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        });
      });
  },

  // 处理状态变更
  handleStatusChange(e) {
    const newStatus = e.detail.value; // 注意这里改为e.detail.value获取单选值
    this.updateReviewStatus(newStatus);
  },

  // 更新反馈状态到数据库
  updateReviewStatus(status) {
    wx.showLoading({
      title: '处理中...',
    });

    const db = wx.cloud.database();
    
    db.collection('comment')
      .doc(this.data.id)
      .update({
        data: {
          status: status
          // 移除了handleTime的更新
        }
      })
      .then(() => {
        wx.hideLoading();
        wx.showToast({
          title: '状态已更新',
          icon: 'success'
        });
        
        // 更新页面数据
        this.setData({
          status: status,
          'review.status': status
        });
        
        // 通知列表页刷新
        const pages = getCurrentPages();
        if (pages.length > 1) {
          const prevPage = pages[pages.length - 2];
          prevPage.loadReviewList && prevPage.loadReviewList();
        }
      })
      .catch(err => {
        console.error('更新状态失败:', err);
        wx.hideLoading();
        wx.showToast({
          title: '更新失败',
          icon: 'none'
        });
      });
  },

  // 返回按钮
  navigateBack() {
    wx.navigateBack({
      delta: 1
    });
  }
});
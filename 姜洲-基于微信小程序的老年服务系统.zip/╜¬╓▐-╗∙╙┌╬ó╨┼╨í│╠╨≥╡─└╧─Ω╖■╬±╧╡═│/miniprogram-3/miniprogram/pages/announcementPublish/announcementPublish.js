const db = wx.cloud.database()

Page({
  data: {
    content: '',
    images: []
  },

  // 内容输入
  onContentChange(e) {
    this.setData({
      content: e.detail.value
    })
  },

  // 选择图片
  chooseImage() {
    const remain = 9 - this.data.images.length
    wx.chooseImage({
      count: remain,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        wx.showLoading({ title: '上传中...', mask: true })
        
        const uploadTasks = res.tempFilePaths.map((path, index) => {
          return wx.cloud.uploadFile({
            cloudPath: `announcements/${Date.now()}-${index}.jpg`,
            filePath: path
          })
        })

        Promise.all(uploadTasks)
          .then(res => {
            this.setData({
              images: [...this.data.images, ...res.map(item => item.fileID)]
            })
          })
          .catch(err => {
            console.error('上传失败:', err)
            wx.showToast({ title: '上传失败', icon: 'none' })
          })
          .finally(() => wx.hideLoading())
      }
    })
  },

  // 删除图片
  removeImage(e) {
    const index = e.currentTarget.dataset.index
    const images = [...this.data.images]
    images.splice(index, 1)
    this.setData({ images })
  },

  // 预览图片
  previewImage(e) {
    wx.previewImage({
      current: e.currentTarget.dataset.url,
      urls: e.currentTarget.dataset.urls
    })
  },

  // 发布公告
  publishAnnouncement() {
    if (!this.data.content.trim()) {
      return wx.showToast({ title: '请输入公告内容', icon: 'none' })
    }

    wx.showLoading({ title: '发布中...', mask: true })

    db.collection('announcements').add({
      data: {
        content: this.data.content,
        images: this.data.images,
        createTime: db.serverDate(),
        views: 0
      }
    })
    .then(() => {
      wx.showToast({ title: '发布成功', icon: 'success' })
      setTimeout(() => {
        wx.navigateBack()
      }, 1500)
    })
    .catch(err => {
      console.error('发布失败:', err)
      wx.showToast({ title: '发布失败', icon: 'none' })
    })
    .finally(() => wx.hideLoading())
  },

  // 返回
  navigateBack() {
    wx.navigateBack()
  }
})
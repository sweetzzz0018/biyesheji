// pages/hospitalDepartments/hospitalDepartments.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    departments: [
      {
        id: 1,
        name: '内科',
        icon: '/imgs/hospital/internal_medicine.png',
        description: '诊治内脏器官疾病，包括心脏病、肺病、消化系统疾病等。'
      },
      {
        id: 2,
        name: '外科',
        icon: '/imgs/hospital/surgery.png',
        description: '通过手术和其他方法治疗疾病、损伤和畸形。'
      },
      {
        id: 5,
        name: '眼科',
        icon: '/imgs/hospital/ophthalmology.png',
        description: '诊断和治疗眼睛疾病，提供视力保健服务。'
      },
      {
        id: 6,
        name: '耳鼻喉科',
        icon: '/imgs/hospital/ent.png',
        description: '处理耳朵、鼻子、喉咙及相关头颈部位的疾病。'
      },
      {
        id: 7,
        name: '呼吸科',
        icon: '/imgs/hospital/dental.png',
        description: '提供呼吸健康服务。'
      },
      {
        id: 8,
        name: '皮肤科',
        icon: '/imgs/hospital/dermatology.png',
        description: '诊断和治疗皮肤、头发和指甲相关的疾病。'
      },
      {
        id: 9,
        name: '神经科',
        icon: '/imgs/hospital/neurology.png',
        description: '专注于神经系统疾病的诊断和治疗。'
      },
      {
        id: 10,
        name: '精神科',
        icon: '/imgs/hospital/psychiatry.png',
        description: '诊断、预防和治疗精神障碍和心理健康问题。'
      },
      {
        id: 11,
        name: '中医科',
        icon: '/imgs/hospital/tcm.png',
        description: '运用中医理论和方法诊治疾病，包括针灸、中药等。'
      },
      {
        id: 12,
        name: '肿瘤科',
        icon: '/imgs/hospital/oncology.png',
        description: '专门研究和治疗各种癌症和肿瘤疾病。'
      }
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 页面加载时可以执行的逻辑
  },

  /**
   * 点击科室卡片，跳转到科室详情页
   */
  goToDepartmentDetail(e) {
    const departmentId = e.currentTarget.dataset.id;
    const department = this.data.departments.find(item => item.id === departmentId);
    
    // 将科室信息转为JSON字符串，通过URL参数传递
    const departmentInfo = encodeURIComponent(JSON.stringify(department));
    
    wx.navigateTo({
      url: `/pages/hospitalDepartmentDetail/hospitalDepartmentDetail?departmentInfo=${departmentInfo}`
    });
  }
})

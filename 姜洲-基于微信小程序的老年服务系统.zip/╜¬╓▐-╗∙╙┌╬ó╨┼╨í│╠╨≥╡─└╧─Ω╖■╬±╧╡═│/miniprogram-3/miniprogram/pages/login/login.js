Page({
  data: {
    username: '',
    password: '',
  },

  // 微信一键登录 - 使用getUserProfile
  onWechatLogin() {
    // 在用户点击按钮时调用getUserProfile
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户信息后的用途
      success: (profileRes) => {
        const userInfo = profileRes.userInfo;

        wx.showLoading({ title: '登录中...' });

        wx.login({
          success: async (loginRes) => {
            if (loginRes.code) {
              try {
                const openidRes = await wx.cloud.callFunction({
                  name: 'getOpenId',
                  data: { code: loginRes.code }
                });
                const openid = openidRes.result.openid;
                const app = getApp();
                app.globalData.openid = openid;
                app.globalData.isLogin = true;

                // 更新全局数据
                app.globalData.userInfo = {
                  ...userInfo,
                  openid: openid
                };

                // 同步到云数据库
                await app.syncToCloudDatabase(userInfo);

                // 持久化到本地
                wx.setStorageSync('userCache', {
                  openid: openid,
                  isLogin: true,
                  userInfo: app.globalData.userInfo
                });

                wx.hideLoading();
                wx.showToast({ title: '登录成功', icon: 'success' });
                wx.switchTab({ url: '/pages/first/first' });
              } catch (err) {
                wx.hideLoading();
                console.error('微信登录失败:', err);
                wx.showToast({ title: '登录失败', icon: 'none' });
              }
            }
          },
          fail: (err) => {
            wx.hideLoading();
            console.error('获取登录凭证失败:', err);
            wx.showToast({ title: '登录失败', icon: 'none' });
          }
        });
      },
      fail: (err) => {
        // 用户拒绝授权
        console.log('用户拒绝授权:', err);
        if (err.errMsg && err.errMsg.includes('auth deny')) {
          wx.showToast({ title: '您拒绝了授权', icon: 'none' });
        }
      }
    });
  },

  // 账号密码输入
  onInputUsername(e) {
    this.setData({ username: e.detail.value });
  },

  onInputPassword(e) {
    this.setData({ password: e.detail.value });
  },

  // 账号密码登录
  async onLogin() {
    const { username, password } = this.data;
    if (!username || !password) {
      wx.showToast({ title: '请输入用户名和密码', icon: 'none' });
      return;
    }

    // 检查是否是管理员登录
    if (username === 'admin' && password === 'admin') {
      wx.showToast({ title: '管理员登录成功', icon: 'success' });
      wx.navigateTo({ url: '/pages/admin/admin' });
      return;
    }

    wx.showLoading({ title: '登录中...' });
    try {
      const db = wx.cloud.database();
      const res = await db.collection('users').where({
        username,
        password,
      }).get();

      if (res.data.length > 0) {
        // 登录成功
        const user = res.data[0];
        const app = getApp();

        // 设置全局变量
        app.globalData.userInfo = user;
        app.globalData.openid = user.openid; // 假设用户集合中有openid字段

        wx.hideLoading();
        wx.showToast({ title: '登录成功', icon: 'success' });
        wx.switchTab({ url: '/pages/first/first' });  // 登录成功后跳转
      } else {
        wx.hideLoading();
        wx.showToast({ title: '用户名或密码错误', icon: 'none' });
      }
    } catch (err) {
      wx.hideLoading();
      wx.showToast({ title: '登录失败', icon: 'none' });
      console.error('账号登录失败:', err);
    }
  },

  // 跳转到注册页面
  goToRegister() {
    wx.navigateTo({ url: '/pages/register/register' });
  }
});

Page({
  navigateToReview() {
    wx.navigateTo({
      url: '/pages/review/review'
    })
  },

  navigateToAnnouncement() {
    wx.navigateTo({
      url: '/pages/announcement/announcement'
    })
  },

  navigateToHospitalAppointments() {
    wx.navigateTo({
      url: '/pages/adminHospital/adminHospital'
    })
  },

  navigateToHomemakingAppointments() {
    wx.navigateTo({
      url: '/pages/adminHomemaking/adminHomemaking'
    })
  }
})
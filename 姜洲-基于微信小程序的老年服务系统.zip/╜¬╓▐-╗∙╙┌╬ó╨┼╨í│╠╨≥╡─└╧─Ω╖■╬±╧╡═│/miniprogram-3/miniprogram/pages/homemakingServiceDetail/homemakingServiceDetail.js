// pages/homemakingServiceDetail/homemakingServiceDetail.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    service: null,
    features: [
      '专业服务人员',
      '全程保险保障',
      '服务质量保证',
      '不满意可重新服务'
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    if (options.serviceInfo) {
      try {
        const service = JSON.parse(decodeURIComponent(options.serviceInfo));
        this.setData({ service });
      } catch (error) {
        console.error('解析服务信息失败:', error);
        wx.showToast({
          title: '加载服务信息失败',
          icon: 'none'
        });
      }
    } else {
      wx.showToast({
        title: '服务信息不存在',
        icon: 'none'
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },

  /**
   * 跳转到预约页面
   */
  goToBooking() {
    if (this.data.service) {
      const serviceTypeIndex = this.getServiceTypeIndex(this.data.service.name);
      
      wx.navigateTo({
        url: `/pages/addHomemaking/addHomemaking?serviceTypeIndex=${serviceTypeIndex}`
      });
    }
  },

  /**
   * 获取服务类型在预约页面中的索引
   */
  getServiceTypeIndex(serviceName) {
    const serviceTypes = [
      '日常保洁', '深度保洁', '家电清洗', '厨房保洁', 
      '卫生间保洁', '开荒保洁', '月嫂服务', '育儿服务', '老人陪护'
    ];
    
    return serviceTypes.findIndex(type => type === serviceName);
  },

  /**
   * 拨打客服电话
   */
  callCustomerService() {
    wx.makePhoneCall({
      phoneNumber: '137xxxxxxxxxxx', 
      success: () => {
        console.log('拨打电话成功');
      },
      fail: (err) => {
        console.error('拨打电话失败:', err);
      }
    });
  }
})

// pages/addHomemaking/addHomemaking.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userId: '',
    serviceTypes: ['日常保洁', '深度保洁', '家电清洗', '厨房保洁', '卫生间保洁', '开荒保洁', '月嫂服务', '育儿服务', '老人陪护'],
    serviceTypeIndex: -1,
    appointmentDate: '',
    minDate: '',
    timeSlots: ['上午 8:00-10:00', '上午 10:00-12:00', '下午 14:00-16:00', '下午 16:00-18:00', '晚上 18:00-20:00'],
    timeSlotIndex: -1,
    address: '',
    contactName: '',
    contactPhone: '',
    remarks: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    // 设置最小日期为当前日期
    const today = new Date();
    const minDate = today.toISOString().split('T')[0];

    // 如果有传入服务类型索引，则设置
    let serviceTypeIndex = -1;
    if (options && options.serviceTypeIndex) {
      serviceTypeIndex = parseInt(options.serviceTypeIndex);
    }

    this.setData({
      minDate,
      serviceTypeIndex
    });

    // 获取用户ID
    const app = getApp();
    if (app.globalData.userInfo && app.globalData.userInfo.openid) {
      this.loadUserId(app.globalData.userInfo.openid);
    } else {
      app.userInfoReadyCallback = (userInfo) => {
        this.loadUserId(userInfo.openid);
      };
    }
  },

  // 通过 openid 查询 userId
  async loadUserId(openid) {
    const db = wx.cloud.database();
    try {
      const res = await db.collection('users').where({ openid }).get();

      if (res.data.length > 0) {
        const userId = res.data[0]._id;
        this.setData({
          userId,
          contactName: res.data[0].nickName || '',
          contactPhone: res.data[0].phone || ''
        });
      } else {
        console.error('未找到用户');
        wx.showToast({
          title: '未找到用户',
          icon: 'none',
        });
      }
    } catch (err) {
      console.error('加载用户信息失败:', err);
      wx.showToast({
        title: '加载用户信息失败',
        icon: 'none',
      });
    }
  },

  // 服务类型选择
  onServiceTypeChange(e) {
    this.setData({
      serviceTypeIndex: parseInt(e.detail.value)
    });
  },

  // 日期选择
  onDateChange(e) {
    this.setData({
      appointmentDate: e.detail.value
    });
  },

  // 时间段选择
  onTimeSlotChange(e) {
    this.setData({
      timeSlotIndex: parseInt(e.detail.value)
    });
  },

  // 输入框变化
  onInputChange(e) {
    const field = e.currentTarget.dataset.field;
    this.setData({
      [field]: e.detail.value
    });
  },

  // 生成预约号
  generateAppointmentNumber() {
    const now = new Date();
    const year = now.getFullYear().toString().substr(2);
    const month = (now.getMonth() + 1).toString().padStart(2, '0');
    const day = now.getDate().toString().padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    return `H${year}${month}${day}${random}`;
  },

  // 提交预约
  async submitAppointment() {
    // 表单验证
    if (this.data.serviceTypeIndex === -1) {
      return wx.showToast({ title: '请选择服务类型', icon: 'none' });
    }
    if (!this.data.appointmentDate) {
      return wx.showToast({ title: '请选择服务日期', icon: 'none' });
    }
    if (this.data.timeSlotIndex === -1) {
      return wx.showToast({ title: '请选择服务时间', icon: 'none' });
    }
    if (!this.data.address) {
      return wx.showToast({ title: '请输入服务地址', icon: 'none' });
    }
    if (!this.data.contactName) {
      return wx.showToast({ title: '请输入联系人姓名', icon: 'none' });
    }
    if (!this.data.contactPhone) {
      return wx.showToast({ title: '请输入联系电话', icon: 'none' });
    }
    if (!/^1\d{10}$/.test(this.data.contactPhone)) {
      return wx.showToast({ title: '请输入正确的手机号', icon: 'none' });
    }

    wx.showLoading({ title: '提交中...' });

    const {
      userId,
      serviceTypes,
      serviceTypeIndex,
      appointmentDate,
      timeSlots,
      timeSlotIndex,
      address,
      contactName,
      contactPhone,
      remarks
    } = this.data;

    try {
      const db = wx.cloud.database();

      // 生成预约号
      const appointmentNumber = this.generateAppointmentNumber();

      // 保存预约信息
      await db.collection('homemaking').add({
        data: {
          userId,
          serviceType: serviceTypes[serviceTypeIndex],
          appointmentDate,
          appointmentTime: timeSlots[timeSlotIndex],
          address,
          contactName,
          contactPhone,
          remarks,
          status: '待确认',
          appointmentNumber,
          createTime: db.serverDate(),
          updateTime: db.serverDate()
        }
      });

      wx.hideLoading();

      // 设置刷新标记
      wx.setStorageSync('homemaking_need_refresh', true);

      wx.showToast({
        title: '预约成功',
        icon: 'success'
      });

      // 延迟返回上一页
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    } catch (err) {
      wx.hideLoading();
      console.error('提交预约失败:', err);
      wx.showToast({
        title: '提交失败',
        icon: 'none'
      });
    }
  }
})

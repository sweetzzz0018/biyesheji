Page({
  data: {
    userId: '', // 从 users 集合中读取的 userId
    reminderId: '', // 当前健康提醒的 _id（如果是编辑模式）
    time: '',
    description: '',
  },

  onLoad(options) {
    // 获取当前用户的 openid
    const openid = getApp().globalData.userInfo.openid;

    // 从 users 集合中读取 userId
    this.loadUserId(openid);

    // 如果是编辑模式，获取 reminderId
    if (options.reminderId) {
      this.setData({ reminderId: options.reminderId });
      this.loadHealthReminder(options.reminderId);
    }
  },

  // 从 users 集合中读取 userId
  async loadUserId(openid) {
    const db = wx.cloud.database();
    try {
      const res = await db.collection('users').where({
        openid: openid,
      }).get();

      if (res.data.length > 0) {
        const userId = res.data[0]._id; // 获取 userId
        this.setData({ userId });
      } else {
        console.error('未找到用户');
        wx.showToast({
          title: '未找到用户',
          icon: 'none',
        });
      }
    } catch (err) {
      console.error('加载用户信息失败:', err);
      wx.showToast({
        title: '加载用户信息失败',
        icon: 'none',
      });
    }
  },

  // 加载健康提醒
  async loadHealthReminder(reminderId) {
    const db = wx.cloud.database();
    try {
      const res = await db.collection('healthReminders').doc(reminderId).get();
      this.setData({
        time: res.data.time,
        description: res.data.description,
      });
    } catch (err) {
      console.error('加载健康提醒失败:', err);
      wx.showToast({
        title: '加载健康提醒失败',
        icon: 'none',
      });
    }
  },

  // 输入框内容变化
  onInputChange(e) {
    const { field } = e.currentTarget.dataset;
    const value = e.detail.value;
    this.setData({
      [field]: value,
    });
  },

  // 保存数据
  async saveData() {
    const { userId, reminderId, time, description } = this.data;

    wx.showLoading({
      title: '保存中...',
    });

    try {
      const db = wx.cloud.database();

      if (reminderId) {
        // 更新现有记录
        await db.collection('healthReminders').doc(reminderId).update({
          data: { time, description },
        });
      } else {
        // 插入新记录
        await db.collection('healthReminders').add({
          data: { userId, time, description },
        });
      }

      wx.hideLoading();
      wx.showToast({
        title: '保存成功',
        icon: 'success',
      });

      // 返回上一页并更新上一页数据
      wx.navigateBack({
        success: function () {
          const pages = getCurrentPages();
          const prevPage = pages[pages.length - 2]; // 获取上一页面实例
          prevPage.onShow(); // 手动调用上一页面的 onShow 方法刷新数据
        }
      });
    } catch (err) {
      wx.hideLoading();
      wx.showToast({
        title: '保存失败',
        icon: 'none',
      });
      console.error('保存失败:', err);
    }
  },

  // 删除数据
  async deleteData() {
    const { reminderId } = this.data;

    wx.showLoading({
      title: '删除中...',
    });

    try {
      const db = wx.cloud.database();
      await db.collection('healthReminders').doc(reminderId).remove();

      wx.hideLoading();
      wx.showToast({
        title: '删除成功',
        icon: 'success',
      });

      // 返回上一页并更新上一页数据
      wx.navigateBack({
        success: function () {
          const pages = getCurrentPages();
          const prevPage = pages[pages.length - 2]; // 获取上一页面实例
          prevPage.onShow(); // 手动调用上一页面的 onShow 方法刷新数据
        }
      });
    } catch (err) {
      wx.hideLoading();
      wx.showToast({
        title: '删除失败',
        icon: 'none',
      });
      console.error('删除失败:', err);
    }
  },

  // 返回 health 页面
  navigateBack() {
    wx.navigateBack();
  },
});

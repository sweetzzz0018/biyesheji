Page({
  data: {
    announcement: {},  // 存储公告的详细数据
  },

  // 页面加载时，获取传递过来的公告ID并加载数据
  onLoad(options) {
    const announcementId = options.id;  // 获取公告ID
    this.loadAnnouncementDetail(announcementId);
  },

  // 加载公告详情
  loadAnnouncementDetail(id) {
    const db = wx.cloud.database();
    db.collection('announcements')
      .doc(id)  // 通过ID查询公告
      .get()
      .then(res => {
        const announcement = res.data;
        this.setData({
          announcement,
        });
        this.incrementViews(id);  // 增加浏览次数
      })
      .catch(err => {
        console.error('加载公告详情失败:', err);
      });
  },

  // 增加浏览次数
  incrementViews(id) {
    const db = wx.cloud.database();
    db.collection('announcements')
      .doc(id)
      .update({
        data: {
          views: db.command.inc(1),  // 增加浏览次数
        },
      })
      .then(() => {
        console.log('浏览次数更新成功');
      })
      .catch(err => {
        console.error('更新浏览次数失败:', err);
      });
  },

  // 返回上一页
  goBack() {
    wx.navigateBack({
      delta: 1,  // 返回上一页
    });
  },
});

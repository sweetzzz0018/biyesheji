const db = wx.cloud.database()
const _ = db.command

Page({
  data: {
    moments: [],
    currentOpenid: null, // 存储静默获取的openid
    isLoading: false,
    isOperating: false,
    userInfo: null, // 添加用户信息存储
    refreshing: false // 下拉刷新状态
  },

  // 开启页面下拉刷新
  onPullDownRefresh() {
    this.setData({ refreshing: true })
    this.loadMoments().then(() => {
      wx.stopPullDownRefresh()
      this.setData({ refreshing: false })
    })
  },

  onLoad() {
    this.getSilentOpenid() // 静默获取用户标识
    this.loadUserData() // 新增：加载当前用户数据
    this.loadMoments()
  },

  // 添加onShow生命周期函数，每次页面显示时刷新数据
  onShow() {
    // 检查是否需要刷新
    const needRefresh = wx.getStorageSync('moments_need_refresh');
    if (needRefresh) {
      // 清除标记
      wx.removeStorageSync('moments_need_refresh');
      // 刷新数据
      this.loadMoments();
    }
  },

  // 加载当前用户数据
  async loadUserData() {
    try {
      const openid = wx.getStorageSync('openid') || this.data.currentOpenid
      if (!openid) {
        console.log('未找到openid，使用默认用户信息');
        this.setData({
          userInfo: {
            nickName: '微信用户',
            avatarUrl: '/imgs/default-avatar.png',
            coverUrl: '/imgs/index/default-cover.jpg'
          }
        });
        return;
      }

      // 1. 直接从userdata集合通过openid查询
      try {
        const directUserdataRes = await db.collection('userdata').where({ openid }).get();
        if (directUserdataRes.data.length > 0) {
          const userData = directUserdataRes.data[0];
          this.setData({
            userInfo: {
              nickName: userData.nickName || '微信用户',
              avatarUrl: userData.avatarUrl || '/imgs/default-avatar.png',
              coverUrl: userData.coverUrl || '/imgs/index/default-cover.jpg'
            }
          });
          console.log('通过openid从userdata获取到用户信息:', userData.nickName);
          return;
        }
      } catch (directErr) {
        console.error('通过openid从userdata获取用户信息失败:', directErr);
      }

      // 2. 如果通过openid找不到，尝试通过userId查询
      try {
        // 先获取users表中的用户ID
        const userRes = await db.collection('users')
          .where({ openid: openid })
          .get();

        if (userRes.data.length === 0) {
          console.log('未找到用户ID，使用默认用户信息');
          this.setData({
            userInfo: {
              nickName: '微信用户',
              avatarUrl: '/imgs/default-avatar.png',
              coverUrl: '/imgs/index/default-cover.jpg'
            }
          });
          return;
        }

        // 获取userdata中的详细信息
        const userdataRes = await db.collection('userdata')
          .where({ userId: userRes.data[0]._id })
          .get();

        if (userdataRes.data.length > 0) {
          const userData = userdataRes.data[0];
          this.setData({
            userInfo: {
              nickName: userData.nickName || '未设置昵称',
              avatarUrl: userData.avatarUrl || '/imgs/default-avatar.png',
              coverUrl: userData.coverUrl || '/imgs/index/default-cover.jpg'
            }
          });
          console.log('通过userId从userdata获取到用户信息:', userData.nickName);
        } else {
          // 如果在userdata中找不到，使用users集合中的信息
          this.setData({
            userInfo: {
              nickName: userRes.data[0].nickName || '微信用户',
              avatarUrl: userRes.data[0].avatarUrl || '/imgs/default-avatar.png',
              coverUrl: '/imgs/index/default-cover.jpg'
            }
          });
        }
      } catch (err) {
        console.error('获取用户数据失败:', err);
        // 出错时使用默认值
        this.setData({
          userInfo: {
            nickName: '微信用户',
            avatarUrl: '/imgs/default-avatar.png',
            coverUrl: '/imgs/index/default-cover.jpg'
          }
        });
      }
    } catch (err) {
      console.error('获取用户数据失败:', err);
      // 出错时使用默认值
      this.setData({
        userInfo: {
          nickName: '微信用户',
          avatarUrl: '/imgs/default-avatar.png',
          coverUrl: '/imgs/index/default-cover.jpg'
        }
      });
    }
  },

  // 静默获取openid（无需用户授权）
  async getSilentOpenid() {
    try {
      const { result } = await wx.cloud.callFunction({
        name: 'getOpenId'
      })
      this.setData({ currentOpenid: result.openid })
      wx.setStorageSync('openid', result.openid) // 存储到缓存
    } catch (err) {
      console.error('获取用户标识失败:', err)
    }
  },

  async loadMoments() {
    if (this.data.isLoading) return Promise.resolve()
    this.setData({ isLoading: true })

    try {
      // 1. 获取动态列表
      const momentsRes = await db.collection('moments')
        .orderBy('createTime', 'desc')
        .get()

      // 处理用户信息
      const processedMoments = [];

      for (const moment of momentsRes.data) {
        // 如果动态中已经包含用户信息，直接使用
        if (moment.user && moment.user.avatarUrl) {
          processedMoments.push({
            ...moment,
            formattedTime: this.formatTime(moment.createTime)
          });
          continue;
        }

        // 如果有userId，尝试从数据库获取用户信息
        if (moment.userId) {
          try {
            // 先从 users 集合中查询
            const userRes = await db.collection('users').doc(moment.userId).get();
            if (userRes.data) {
              processedMoments.push({
                ...moment,
                formattedTime: this.formatTime(moment.createTime),
                user: {
                  nickName: userRes.data.nickName || '微信用户',
                  avatarUrl: userRes.data.avatarUrl || '/imgs/default-avatar.png',
                  openid: userRes.data.openid
                }
              });
              continue;
            }
          } catch (userErr) {
            console.log('从 users 集合获取用户信息失败:', userErr);

            // 如果失败，尝试从 userdata 集合中查询
            try {
              const userdataRes = await db.collection('userdata').where({ userId: moment.userId }).get();
              if (userdataRes.data.length > 0) {
                processedMoments.push({
                  ...moment,
                  formattedTime: this.formatTime(moment.createTime),
                  user: {
                    nickName: userdataRes.data[0].nickName || '微信用户',
                    avatarUrl: userdataRes.data[0].avatarUrl || '/imgs/default-avatar.png',
                    openid: userdataRes.data[0].openid
                  }
                });
                continue;
              }
            } catch (userdataErr) {
              console.log('从 userdata 集合获取用户信息失败:', userdataErr);
            }
          }
        }

        // 如果有user.openid，优先从userdata集合获取用户信息，然后再尝试从users集合获取
        if (moment.user && moment.user.openid) {
          try {
            // 先尝试通过openid直接从userdata获取
            const userdataRes = await db.collection('userdata').where({ openid: moment.user.openid }).get();
            if (userdataRes.data.length > 0) {
              processedMoments.push({
                ...moment,
                formattedTime: this.formatTime(moment.createTime),
                user: {
                  ...moment.user,
                  nickName: userdataRes.data[0].nickName || moment.user.nickName || '微信用户',
                  avatarUrl: userdataRes.data[0].avatarUrl || moment.user.avatarUrl || '/imgs/default-avatar.png'
                }
              });
              console.log('通过openid从userdata获取到用户信息:', userdataRes.data[0].nickName);
              continue;
            }

            // 如果从userdata获取失败，再尝试从users集合获取
            const userRes = await db.collection('users').where({ openid: moment.user.openid }).get();
            if (userRes.data.length > 0) {
              processedMoments.push({
                ...moment,
                formattedTime: this.formatTime(moment.createTime),
                user: {
                  ...moment.user,
                  nickName: userRes.data[0].nickName || moment.user.nickName || '微信用户',
                  avatarUrl: userRes.data[0].avatarUrl || moment.user.avatarUrl || '/imgs/default-avatar.png'
                }
              });
              continue;
            }
          } catch (err) {
            console.log('通过openid获取用户信息失败:', err);
          }
        }

        // 如果上述方法都失败，使用默认值
        processedMoments.push({
          ...moment,
          formattedTime: this.formatTime(moment.createTime),
          user: {
            ...moment.user,
            nickName: moment.user?.nickName || '微信用户',
            avatarUrl: moment.user?.avatarUrl || '/imgs/default-avatar.png'
          }
        });
      }

      this.setData({ moments: processedMoments })
      return Promise.resolve()
    } catch (err) {
      console.error('加载失败:', err)
      wx.showToast({ title: '加载失败', icon: 'none' })
      return Promise.reject(err)
    } finally {
      this.setData({ isLoading: false })
    }
  },

  // 优化时间格式化方法
  formatTime(timestamp) {
    const date = new Date(timestamp)
    const now = new Date()
    const diffDays = Math.floor((now - date) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) {
      return `今天 ${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`
    } else if (diffDays === 1) {
      return `昨天 ${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`
    } else {
      return `${date.getMonth()+1}月${date.getDate()}日 ${date.getHours()}:${date.getMinutes().toString().padStart(2, '0')}`
    }
  },

  // 其他方法保持不变
  previewImage(e) {
    wx.previewImage({
      current: e.currentTarget.dataset.current,
      urls: e.currentTarget.dataset.urls
    })
  },

  goPost() {
    wx.navigateTo({ url: '/pages/post/post' })
  },

  goProfile() {
    wx.navigateTo({ url: '/pages/profile/profile' })
  },

  goDetail(e) {
    wx.navigateTo({
      url: `/pages/post-detail/post-detail?id=${e.currentTarget.dataset.id}`
    })
  },

  // 点赞功能
  async toggleLike(e) {
    if (this.data.isOperating) return
    this.setData({ isOperating: true })

    try {
      const postId = e.currentTarget.dataset.id

      // 确保已获取openid
      let openid = this.data.currentOpenid
      if (!openid) {
        const { result } = await wx.cloud.callFunction({
          name: 'getOpenId'
        })
        openid = result.openid
        this.setData({ currentOpenid: openid })
      }

      // 查找当前动态
      const post = this.data.moments.find(item => item._id === postId)
      if (!post) {
        throw new Error('动态不存在')
      }

      // 检查是否已点赞
      const isLiked = post.likes && post.likes.includes(openid)
      if (isLiked) {
        wx.showToast({ title: '您已经点过赞了', icon: 'none' })
        this.setData({ isOperating: false })
        return
      }

      // 执行点赞
      await db.collection('moments').doc(postId).update({
        data: {
          likes: _.push(openid)
        }
      })

      // 更新本地数据
      const updatedMoments = this.data.moments.map(item => {
        if (item._id === postId) {
          // 确保likes是数组
          const likes = item.likes || []
          return {
            ...item,
            likes: [...likes, openid]
          }
        }
        return item
      })

      this.setData({
        moments: updatedMoments,
        isOperating: false
      })

      wx.showToast({ title: '点赞成功', icon: 'success' })
    } catch (err) {
      console.error('点赞失败:', err)
      wx.showToast({ title: '操作失败', icon: 'none' })
      this.setData({ isOperating: false })
    }
  }
})
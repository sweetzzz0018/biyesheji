Page({
  data: {
    userId: '', // 从 users 集合中读取的 userId
    height: '',
    weight: '',
    medicalHistory: '', // 新增病史字段
  },

  onLoad(options) {
    // 获取当前用户的 openid
    const openid = getApp().globalData.userInfo.openid;

    // 从 users 集合中读取 userId
    this.loadUserId(openid);
  },

  // 从 users 集合中读取 userId
  async loadUserId(openid) {
    const db = wx.cloud.database();
    try {
      console.log('正在查询 users 集合...'); // 调试信息
      const res = await db.collection('users').where({
        openid: openid,
      }).get();

      if (res.data.length > 0) {
        const userId = res.data[0]._id; // 获取 userId
        this.setData({ userId });

        // 加载健康档案
        this.loadHealthProfile(userId);
      } else {
        console.error('未找到用户');
        wx.showToast({
          title: '未找到用户',
          icon: 'none',
        });
      }
    } catch (err) {
      console.error('加载用户信息失败:', err);
      wx.showToast({
        title: '加载用户信息失败',
        icon: 'none',
      });
    }
  },

  // 加载健康档案
  async loadHealthProfile(userId) {
    const db = wx.cloud.database();
    try {
      console.log('正在查询 healthProfiles 集合...'); // 调试信息
      const res = await db.collection('healthProfiles').where({
        userId: userId,
      }).get();

      if (res.data.length > 0) {
        this.setData({
          height: res.data[0].height,
          weight: res.data[0].weight,
          medicalHistory: res.data[0].medicalHistory, // 加载病史
        });
      } else {
        console.log('未找到健康档案');
      }
    } catch (err) {
      console.error('加载健康档案失败:', err);
      wx.showToast({
        title: '加载健康档案失败',
        icon: 'none',
      });
    }
  },

  // 输入框内容变化
  onInputChange(e) {
    const { field } = e.currentTarget.dataset;
    const value = e.detail.value;
    this.setData({
      [field]: value,
    });
  },

// 在保存数据成功后返回并刷新主页面
async saveData() {
  const { userId, height, weight, medicalHistory } = this.data;

  wx.showLoading({
    title: '保存中...',
  });

  try {
    const db = wx.cloud.database();

    // 更新或插入健康档案
    const res = await db.collection('healthProfiles').where({
      userId: userId,
    }).get();

    if (res.data.length > 0) {
      // 更新现有记录
      await db.collection('healthProfiles').doc(res.data[0]._id).update({
        data: { height, weight, medicalHistory }, // 包含病史
      });
    } else {
      // 插入新记录
      await db.collection('healthProfiles').add({
        data: { userId, height, weight, medicalHistory }, // 包含病史
      });
    }

    wx.hideLoading();
    wx.showToast({
      title: '保存成功',
      icon: 'success',
    });

    // 返回并刷新数据
    wx.navigateBack({
      delta: 1,
      success: function () {
        // 通过页面栈获取当前页面
        const pages = getCurrentPages();
        const prevPage = pages[pages.length - 2];  // 上一页

        // 调用上一页的刷新函数
        if (prevPage && prevPage.refreshData) {
          prevPage.refreshData(); 
        }
      }
    });
  } catch (err) {
    wx.hideLoading();
    wx.showToast({
      title: '保存失败',
      icon: 'none',
    });
    console.error('保存失败:', err);
  }
},

  // 返回 health 页面
  navigateBack() {
    wx.navigateBack();
  },
});
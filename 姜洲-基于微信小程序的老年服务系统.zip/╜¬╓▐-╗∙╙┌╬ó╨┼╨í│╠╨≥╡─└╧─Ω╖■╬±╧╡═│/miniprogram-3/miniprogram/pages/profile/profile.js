const db = wx.cloud.database()

const withLoading = async (promise, title = '处理中...') => {
  wx.showLoading({ title, mask: true })
  try {
    return await promise
  } finally {
    wx.hideLoading()
  }
}

Page({
  data: {
    userdata: null,
    isLoading: false,
    genderOptions: ['男', '女'],
    envId: 'cloud1-0gdsjui311f1ca70',
    modifiedData: {},
    inputStatus: {
      name: { focused: false, tempValue: '' },
      age: { focused: false, tempValue: '' }
    }
  },

  onLoad() {
    this.safeInitUserData()
  },

  async safeInitUserData() {
    try {
      await withLoading(this.initUserData(), '初始化中...')
    } catch (err) {
      console.error('初始化失败:', err)
      this.showErrorToast(err)
    }
  },

  async initUserData() {
    const openid = await this.getUserOpenIdWithRetry()
    const userId = await this.getUserIdFromUsers(openid)
    await this.loadOrCreateUserData(userId)
  },

  async getUserIdFromUsers(openid) {
    try {
      const res = await db.collection('users').where({
        openid: openid
      }).get()
      
      if (res.data.length > 0) {
        return res.data[0]._id
      } else {
        const addRes = await db.collection('users').add({
          data: {
            openid: openid,
            createTime: db.serverDate()
          }
        })
        return addRes._id
      }
    } catch (err) {
      console.error('获取用户ID失败:', err)
      throw new Error('获取用户信息失败')
    }
  },

  async getUserOpenIdWithRetry(retryCount = 0) {
    const maxRetry = 2
    try {
      let openid = getApp().globalData.openid || wx.getStorageSync('openid')

      if (!openid) {
        const res = await withLoading(
          wx.cloud.callFunction({
            name: 'login',
            config: { env: this.data.envId }
          }),
          '获取身份信息...'
        )
        openid = res.result.openid
        this.cacheOpenId(openid)
      }
      return openid
    } catch (err) {
      if (retryCount < maxRetry) {
        await new Promise(resolve => setTimeout(resolve, 1000))
        return this.getUserOpenIdWithRetry(retryCount + 1)
      }
      throw new Error('获取用户标识失败')
    }
  },

  async loadOrCreateUserData(userId) {
    try {
      const userdata = await withLoading(this.tryGetUserData(userId), '加载数据...')
      this.setUserData(userdata)
    } catch (err) {
      if (err.errCode === 'DATABASE_DOC_NOT_EXIST') {
        const newUser = await withLoading(this.createUserDocument(userId), '初始化资料...')
        this.setUserData(newUser)
      } else {
        throw err
      }
    }
  },

  async tryGetUserData(userId) {
    const res = await db.collection('userdata').where({
      userId: userId
    }).get()
    
    if (res.data.length === 0) throw { errCode: 'DATABASE_DOC_NOT_EXIST' }
    return this.formatUserData(res.data[0])
  },

  async createUserDocument(userId) {
    const defaultData = {
      nickName: '',
      avatarUrl: '/imgs/default-avatar.png',
      coverUrl: '/imgs/index/default-cover.jpg',
      gender: '未填写',
      age: '',
      createTime: db.serverDate(),
      updateTime: db.serverDate(),
      userId: userId
    }
  
    await db.collection('userdata').add({
      data: defaultData
    })
    
    return defaultData
  },

  async changeCover() {
    try {
      const res = await withLoading(
        wx.chooseMedia({
          count: 1,
          mediaType: ['image'],
          sourceType: ['album', 'camera'],
          sizeType: ['compressed']
        }),
        '准备中...'
      )

      const uploadRes = await withLoading(
        wx.cloud.uploadFile({
          cloudPath: `covers/${this.data.userdata.openid}/${Date.now()}.jpg`,
          filePath: res.tempFiles[0].tempFilePath
        }),
        '上传中...'
      )

      this.setData({
        modifiedData: {
          ...this.data.modifiedData,
          coverUrl: uploadRes.fileID
        },
        'userdata.coverUrl': uploadRes.fileID // 立即更新显示
      })
    } catch (err) {
      if (err.errMsg !== 'chooseMedia:fail cancel') {
        wx.showToast({ title: '更换封面失败', icon: 'none' })
      }
    }
  },

  async changeAvatar() {
    try {
      const res = await withLoading(
        wx.chooseMedia({
          count: 1,
          mediaType: ['image'],
          sourceType: ['album', 'camera'],
          sizeType: ['compressed']
        }),
        '准备中...'
      )

      const uploadRes = await withLoading(
        wx.cloud.uploadFile({
          cloudPath: `avatars/${this.data.userdata.openid}/${Date.now()}.jpg`,
          filePath: res.tempFiles[0].tempFilePath
        }),
        '上传中...'
      )

      this.setData({
        modifiedData: {
          ...this.data.modifiedData,
          avatarUrl: uploadRes.fileID
        },
        'userdata.avatarUrl': uploadRes.fileID // 立即更新显示
      })
    } catch (err) {
      if (err.errMsg !== 'chooseMedia:fail cancel') {
        wx.showToast({ title: '更换头像失败', icon: 'none' })
      }
    }
  },

  cacheOpenId(openid) {
    wx.setStorageSync('openid', openid)
    getApp().globalData.openid = openid
  },

  formatUserData(data) {
    return {
      nickName: data.nickName || '',
      avatarUrl: data.avatarUrl || '/imgs/default-avatar.png',
      coverUrl: data.coverUrl || '/imgs/index/default-cover.jpg',
      gender: data.gender || '未填写',
      age: data.age || '',
      openid: data.openid,
      createTime: data.createTime,
      updateTime: data.updateTime,
      userId: data.userId
    }
  },

  setUserData(data) {
    this.setData({ 
      userdata: data,
      modifiedData: {},
      'inputStatus.name.tempValue': data.nickName || '',
      'inputStatus.age.tempValue': data.age || ''
    })
    getApp().globalData.userdata = data
  },

  showErrorToast(err) {
    let title = '数据加载失败'
    if (err.errCode === 'DATABASE_PERMISSION_DENIED') title = '无权限访问数据'
    wx.showToast({ title, icon: 'none' })
  },

  handleInputFocus(e) {
    const field = e.currentTarget.dataset.field
    this.setData({
      [`inputStatus.${field}.focused`]: true,
      [`inputStatus.${field}.tempValue`]: this.data.userdata[field === 'name' ? 'nickName' : field] || ''
    })
  },

  handleInputBlur(e) {
    const field = e.currentTarget.dataset.field
    this.setData({
      [`inputStatus.${field}.focused`]: false
    })
  },

  updateNickname(e) {
    const value = e.detail.value
    this.setData({
      'inputStatus.name.tempValue': value,
      'userdata.nickName': value, // 立即更新显示
      modifiedData: {
        ...this.data.modifiedData,
        nickName: value.trim()
      }
    })
  },

  updateAge(e) {
    const value = e.detail.value.replace(/\D/g, '')
    this.setData({
      'inputStatus.age.tempValue': value,
      'userdata.age': value, // 立即更新显示
      modifiedData: {
        ...this.data.modifiedData,
        age: value
      }
    })
  },

  showGenderPicker() {
    wx.showActionSheet({
      itemList: this.data.genderOptions,
      success: (res) => {
        const value = this.data.genderOptions[res.tapIndex]
        this.setData({
          'userdata.gender': value, // 立即更新显示
          modifiedData: {
            ...this.data.modifiedData,
            gender: value
          }
        })
      }
    })
  },

  async saveAllData() {
    if (Object.keys(this.data.modifiedData).length === 0) {
      wx.showToast({ title: '没有修改需要保存', icon: 'none' })
      return
    }

    try {
      const { userId } = this.data.userdata

      // 验证年龄
      if ('age' in this.data.modifiedData) {
        const age = parseInt(this.data.modifiedData.age)
        if (isNaN(age) || age < 0 || age > 150) {
          wx.showToast({ title: '请输入有效年龄(0-150)', icon: 'none' })
          return
        }
      }

      // 先查询文档ID
      const queryRes = await db.collection('userdata').where({
        userId: userId
      }).get()

      if (queryRes.data.length === 0) {
        throw new Error('用户数据不存在')
      }

      await withLoading(
        db.collection('userdata')
          .doc(queryRes.data[0]._id)
          .update({
            data: {
              ...this.data.modifiedData,
              updateTime: db.serverDate()
            }
          }),
        '保存中...'
      )

      // 更新本地数据
      const newData = { 
        ...this.data.userdata, 
        ...this.data.modifiedData 
      }
      this.setUserData(newData)
      wx.showToast({ 
        title: '保存成功', 
        icon: 'success',
        success: () => {
          setTimeout(() => {
            wx.navigateBack()
          }, 1000)
        }
      })
    } catch (err) {
      console.error('保存失败:', err)
      wx.showToast({ title: err.message || '保存失败', icon: 'none' })
    }
  },

  goBack() {
    wx.navigateBack()
  }
})
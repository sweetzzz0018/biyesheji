// pages/review/review.js
Page({
  data: {
    reviewList: [] // 存储反馈列表数据
  },

  onLoad() {
    this.loadReviewList();
  },

  // 从云数据库加载反馈列表
  loadReviewList() {
    wx.showLoading({
      title: '加载中...',
    });

    const db = wx.cloud.database();
    db.collection('comment')
      .orderBy('createTime', 'desc')
      .get()
      .then(res => {
        this.setData({
          reviewList: res.data
        });
        wx.hideLoading();
      })
      .catch(err => {
        console.error('加载反馈失败:', err);
        wx.hideLoading();
        wx.showToast({
          title: '加载失败',
          icon: 'none'
        });
      });
  },

  // 格式化时间显示
  formatTime(timestamp) {
    const date = new Date(timestamp);
    return `${date.getFullYear()}-${date.getMonth()+1}-${date.getDate()} ${date.getHours()}:${date.getMinutes()}`;
  },

  // 跳转到反馈详情页
  viewReviewDetail(e) {
    const id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: `/pages/reviewDetail/reviewDetail?id=${id}`
    });
  },
  navigateBack() {
    wx.navigateBack({
      delta: 1
    })
  },
  // 下拉刷新
  onPullDownRefresh() {
    this.loadReviewList(() => {
      wx.stopPullDownRefresh();
    });
  }
});